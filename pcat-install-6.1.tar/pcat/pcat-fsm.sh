#!/bin/sh
#######################################################################
#
# Copyright(c) 2010 - 2013 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Author:      Alan Robertson
# Co-Author:		Bernhard Buehler
# Support:              https://cs.opensource.ibm.com/projects/powercat
#
#######################################################################
#
#       Command to gather data from HMCs for a variety of assessments
#
#######################################################################
if [ "$PCATDEBUG" = "on" ]; then set -x; fi
CMDSUFFIX=-fsm-cmds.txt
EXTSUFFIX=-fsm-ext.sh
LS=/bin/ls
usage() {
  cat <<-! >&2
	Script or usage     E R R O R
	You should never be here \!\!\!

	usage: $0 [assessment-type] HMC-name-or-address
	$0 collects HMC data for assessments and evaluations.compute_startdir
	If you don't have (or put) a passphrase-less ssh key on the HMC in question
	then you will have to provide a password to $HMCID a number of times.

	Command files must be provided for $0 to know what you want done.
	They are named assessment-type$CMDSUFFIX and are mandatory.

	Extension files are written in shell syntax, and are provided for the HMC
	commands in rule files to use.  These can be used to add new
	command/action/keywords for use in the command configuration files.
	Extension files are optional.

	The default assessment-type is 'aa'.
	    The corresponding default configuration file is aa$CMDSUFFIX
	    The corresponding default extension file is is aa$EXTSUFFIX

	!
  exit 1
}

#
#	A few reasonable articles about the HMC command line interface
#
#	The official CLI documentation - man-page style.
#	http://www.redbooks.ibm.com/abstracts/SG247038.html
#		which points to http://www.redbooks.ibm.com/redbooks/pdfs/sg247038.pdf
#	http://www.ibm.com/developerworks/wikis/display/LinuxP/HMC+command+line
#	http://www.unixwerk.eu/aix/hmc-howto.html
#	http://www.ibmsystemsmag.com/print/print.aspx?print_page=%2Faix%2Fenewsletterexclusive%2F25542printp1.aspx
#
#
#



#
#	Where should we find our rule files, etc?
#

#
cleanHMCname() {
    out "$1"  | tr  ' /:' '___'
}

#
#	Get the name of the given HMC, and the map of its managed systems and LPARs.
#	We "store" them in a directory structure.
#	Directory names are constrained by OSes, but HMC namings are not
#
acquire_HMC_topology() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  out "Acquiring FSM topology for $1" >&2
  HMCNAME=`$SSH $HMCID@$1 "$HMCNAME_CMD"`
  out "FSM at $1 is named ${HMCNAME}" >&2
  if
    [ -z "$HMCNAME" -o "$HMCNAME" = localhost ]
  then
    HMCNAME="$1"
  fi
  HMCDIR=`cleanHMCname "$HMCNAME"`.d
  test -d "$HMCOUTDIR/${HMCDIR}" || mkdir -p "$HMCOUTDIR/${HMCDIR}"
  out "$HMCNAME" > "$HMCOUTDIR/${HMCDIR}/.realname"
 #
 # Get list of systems and create an output directory for it
 #
  $SSH $HMCID@$1 "$LISTSYS_CMD" |
  while
    read sysname
  do
    if [ "$sysname" = .realname ]; then continue; fi
    sysdir=`cleanHMCname "${sysname}"`.d
    test  -d "$HMCOUTDIR/${HMCDIR}/$sysdir" || mkdir -p "$HMCOUTDIR/${HMCDIR}/${sysdir}"
    out "$sysname" > "$HMCOUTDIR/${HMCDIR}/${sysdir}/.realname"
  done
  #  Loop over the list of System directories -- we will query them for LPARs
  #  (that these directory names won't have blanks in them - so this loop is just fine)
  for SysNameDir in $($LS "$HMCOUTDIR/${HMCDIR}")
  do
    if [ "$SysNameDir" = .realname -o ! -d "$HMCOUTDIR/${HMCDIR}/${SysNameDir}" ]; then continue; fi
    sysname=`cat $HMCOUTDIR/${HMCDIR}/${SysNameDir}/.realname`
    out "Acquiring list of LPARs for $sysname from $1" >&2
    $SSH $HMCID@$1 "lssyscfg -r lpar -m \"$sysname\" -F name" |
    while
      read lpar
    do
      LPARdirname="$HMCOUTDIR/${HMCDIR}/$SysNameDir/$(cleanHMCname "$lpar").d"
      test  -d "$LPARdirname" || mkdir -p "$LPARdirname"
      out "$lpar" > "$LPARdirname/.realname"
    done
  done
  out "Acquiring list of frames from FSM $1" >&2
  $SSH $HMCID@$1 "$LISTFRAMES_CMD" |
  while
    read framename
  do
    framedir=`cleanHMCname "${framename}"`.frame
    test  -d "$HMCOUTDIR/${HMCDIR}/$framedir" || mkdir -p "$HMCOUTDIR/${HMCDIR}/${framedir}"
    out "$framename" > "$HMCOUTDIR/${HMCDIR}/${framedir}/.realname"
  done
}

####
# check if lshmc is working on fsm -- No :-(
# the command which does not work at all !!  :-((
# need to rewrite this !!!
#
is_hmc_sane() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  tmpfoo=/tmp/$$.hmc-sanity-check
  cat <<-'!'  | $SSH $HMCID@$1 > $tmpfoo
	echo PATH=$PATH 
	smcli lsbundle  2>&1
	lshmc -l 2>&1
	!
  hmcpath=`grep  '^PATH=' $tmpfoo`
  if
    grep '^locale' $tmpfoo >/dev/null
  then
    HAVE_ENV=1
  fi
  if
    grep 'getStatus' $tmpfoo >/dev/null
  then
    HAVE_GOODPATH=1
  fi
  rm -fr $tmpfoo
  
  if
    [ $HAVE_ENV -eq 1 -o $HAVE_GOODPATH -eq 1 ]
  then
    true
  else
    out "#####################"
    out "###   E R R O R   ###"
    out "#####################"
    out "FATAL FSM ERROR: FSM id $HMCID@$1 has serious PATH configuration problems."
    out "HMC id $HMCID@$1: $hmcpath"
    out ""
    out "Check if you are connected to a HMC or a FSM ! !"
    out "If an FSM is used you may have to use the flag --id "
    false
  fi
}

#
#	Reads standard in for a list of commands to run
#	Arguments are:
#	$1:	delimiter to use in the here document we generate
#	$2:	The directory to put the output into
#	Remaining args:
#		Arguments to be appended to each command we read from stdin
#
#	We create a script (#1) which we run on the HMC.
#	The output of this script is in turn another script (#2) which we
#	run on our side to direct the output from the various HMC commands
#	into separate files - one per command.
#	
#	Script #2 consists solely of cat commands taking input from here documents
#	generated on the HMC, and redirecting the output into the "appropriate" filename
#	on our side according to where we think it ought to go.
#
#	This allows us to minimize the number of ssh calls we have to make to the HMC
#	and yet not have to parse the output from the HMC in the shell - which would
#	be painful and annoying.
#
create_hmc_cmd_and_output() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  delim="$1"
  outdir="$2"
  shift; shift
  while
    read cmd
  do
   outfilename="$outdir/`cmdtoname $cmd`"
   total=`expr \`cat $CMDCOUNT\` + 1`
   out $total > $CMDCOUNT
   cat <<-!CreateHMCCmdAndOutput

	echo 'cat <<'\''!!$delim'\'' >"$outfilename"'
	echo "==== This output can be found in $outfilename ===="
	echo "==== START command `echo "$cmd $@" | tr  -d '"'` \`date\` ===="
	$cmd`create_quoted_args "$@"`  2>&1
	echo "==== END command `echo "$cmd $@" | tr  -d '"'` \`date\` ===="
	echo !!$delim
	!CreateHMCCmdAndOutput
  done
}

create_fsm_cmd_and_output() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  delim="$1"
  outdir="$2"
  shift; shift
  while
    read cmd
  do
   outfilename="$outdir/`cmdtoname $cmd`"
   total=`expr \`cat $CMDCOUNT\` + 1`
   out $total > $CMDCOUNT
   cat <<-!CreateHMCCmdAndOutput

	echo 'cat <<'\''!!$delim'\'' >"$outfilename"'
	echo "==== This output can be found in $outfilename ===="
	echo "==== START command `echo "$FSMCLI $cmd $@" | tr  -d '"'` \`date\` ===="
	$FSMCLI $cmd`create_quoted_args "$@"`  2>&1
	echo "==== END command `echo "$FSMCLI $cmd $@" | tr  -d '"'` \`date\` ===="
	echo !!$delim
	!CreateHMCCmdAndOutput
  done
}

create_FSM_commands() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  grep -i '^FSM	' < "$1"	|
  cut -d'	' -f2-		|
  create_hmc_cmd_and_output "__FSM_CMDS_$$" "$HMCOUTDIR/${HMCDIR}" 
}

create_FSMCLI_commands() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  grep -i '^FSMCLI	' < "$1"	|
  cut -d'	' -f2-		|
  create_fsm_cmd_and_output "__FSMCLI_CMDS_$$" "$HMCOUTDIR/${HMCDIR}" 
}

create_System_commands() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  $LS "$HMCOUTDIR/${HMCDIR}"  | grep '\.d$' |
  while
    read dirname
  do
    dirname="$HMCOUTDIR/${HMCDIR}/$dirname"
    sysname=`cat $dirname/.realname`
    grep -i '^SYS	' < "$1"	|
    cut -d'	' -f2-		|
    create_hmc_cmd_and_output "__SYS_CMDS_$$" "$dirname" -m "$sysname"
  done
}

create_System_commands_fsm() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  $LS "$HMCOUTDIR/${HMCDIR}"  | grep '\.d$' |
  while
    read dirname
  do
    dirname="$HMCOUTDIR/${HMCDIR}/$dirname"
    sysname=`cat $dirname/.realname`
    grep -i '^SYSCLI	' < "$1"	|
    cut -d'	' -f2-		|
    create_fsm_cmd_and_output "__SYSCLI_CMDS_$$" "$dirname" -m "$sysname"
  done
}

create_Frame_commands() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  $LS "$HMCOUTDIR/${HMCDIR}"  | grep '\.frame$' |
  while
    read dirname
  do
    dirname="$HMCOUTDIR/${HMCDIR}/$dirname"
    framename=`cat $dirname/.realname`
    grep -i '^FRAME	' < "$1"	|
    cut -d'	' -f2-		|
    create_hmc_cmd_and_output "__FRAME_CMDS_$$" "$dirname" -e "$framename"
  done
}

create_Frame_commands_fsm() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  $LS "$HMCOUTDIR/${HMCDIR}"  | grep '\.frame$' |
  while
    read dirname
  do
    dirname="$HMCOUTDIR/${HMCDIR}/$dirname"
    framename=`cat $dirname/.realname`
    grep -i '^FRAMECLI	' < "$1"	|
    cut -d'	' -f2-		|
    create_fsm_cmd_and_output "__FRAMECLI_CMDS_$$" "$dirname" -e "$framename"
  done
}

create_LPAR_commands() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  $LS "$HMCOUTDIR/${HMCDIR}"  | grep '\.d$' |
  while
    read dirname
  do
    dirname="$HMCOUTDIR/${HMCDIR}/$dirname"
    sysname=`cat $dirname/.realname`
    $LS "$dirname"  | grep '\.d$' |
    while
      read lpardirname
    do
      lpardirname="$dirname/$lpardirname"
      lparname=`cat $lpardirname/.realname`
      grep -i '^LPAR	' < "$1"	|
      cut -d'	' -f2-		|
      create_hmc_cmd_and_output "__LPAR_CMDS_$$" "$lpardirname" -m "$sysname" --filter "lpar_names=$lparname"
    done
  done
}

create_LPAR_commands_fsm() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  $LS "$HMCOUTDIR/${HMCDIR}"  | grep '\.d$' |
  while
    read dirname
  do
    dirname="$HMCOUTDIR/${HMCDIR}/$dirname"
    sysname=`cat $dirname/.realname`
    $LS "$dirname"  | grep '\.d$' |
    while
      read lpardirname
    do
      lpardirname="$dirname/$lpardirname"
      lparname=`cat $lpardirname/.realname`
      grep -i '^LPARCLI	' < "$1"	|
      cut -d'	' -f2-		|
      create_fsm_cmd_and_output "__LPARCLI_CMDS_$$" "$lpardirname" -m "$sysname" --filter "lpar_names=$lparname"
    done
  done
}

create_setup_commands() {
 cat <<-'!SETUP'
	LANG='C'; export LANG
	LC_ALL='C'; export LC_ALL
	#
	#       Our slightly fancier version of 'cat'
	#
	fileprint() {
	  for file
	  do
	    printf "==== BEGIN Contents of $file ====\n"
	    cat $file
	    rc=$?
	    printf "==== END Contents of $file (rc=$rc) ====\n"
	    return $rc
	  done
	}
	fileprintnl() {
	  for file
	  do
	    printf "==== BEGIN Contents of $file ====\n"
	    cat $file
	    rc=$?
	    printf "\n==== END Contents of $file (rc=$rc) ====\n"
	    return $rc
	  done
	}
!SETUP
  if
    [ -f "$1" -a -r "$1" ]
  then
    cat "$1"
  fi
}

analyzeAnHMC() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  test -d "$HMCOUTDIR" || mkdir -p "$HMCOUTDIR"
  configcmds="$STARTDIR/$1$CMDSUFFIX"
  configfuns="$STARTDIR/$1$EXTSUFFIX"
  create_setup_commands "$configfuns"
  acquire_HMC_topology "$2"
  # None of the commands below appears to use their "$2"
  # they instead seem to use ${HMCDIR} (which is sligtly more useful to them)
  create_FSM_commands "$configcmds" "$2"
  create_FSMCLI_commands "$configcmds" "$2"
#  create_System_commands "$configcmds" "$2"
  create_System_commands_fsm "$configcmds" "$2"
#  create_LPAR_commands "$configcmds" "$2"
  create_LPAR_commands_fsm "$configcmds" "$2"
#  create_Frame_commands "$configcmds" "$2"
  create_Frame_commands_fsm "$configcmds" "$2"
}

run_hmc_script() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if
    [ $HAVE_GOODPATH -eq 1 ]
  then
    $SSH -q -T "$1" <  "$2" 2>&1 | $SH
  else
    echo "rm -fr \"$2\"" >> "$2";
    $SCP "$2" "$1":"$2"
    $SSH "$1" env /bin/sh "$2" 2>&1 | $SH
  fi
}

AcquireHMCInfo() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  tmpname=/tmp/$$.`uname -n`.$RANDOM.hmcquery
  trap 'rm -f $tmpname' 0
  if 
    is_hmc_sane "$2"
  then
    : Cool!
  else
    exit 1
  fi
  out 0 >$CMDCOUNT
  analyzeAnHMC "$1" "$2"  "$tmpname" > $tmpname
  echo "rm -f $tmpname" >> $tmpname
  out "Running `cat $CMDCOUNT` query commands on HMC $2" >&2
  out "	(these take about seconds or up to a minute each depending on system load and command used)" >&2
  rm -fr $CMDCOUNT
  run_hmc_script "$HMCID@$2" "$tmpname"
}

##########################################################################
# main
##########################################################################
if [ "$PCATDEBUG" = "on" ]; then set -x; fi

# BASEDIR=`compute_startdir`
. $BASEDIR/commonpcatdefs.sh

CMDCOUNT=/tmp/$$.cmdcounts

STARTDIR=${BASEDIR}

HAVE_ENV=0
HAVE_GOODPATH=0

FSMCLI="smcli"
 
# HMCNAME_CMD='lshmc -n -F hostname'
HMCNAME_CMD='uname -n'
LISTSYS_CMD='lssyscfg -r sys -Fname'
LISTLPARS_CMD='lssyscfg -r lpar -m $sysname'
LISTFRAMES_CMD='lssyscfg -r frame -F name|grep -v "No results were found"'

SSH="ssh $SSH_OPTIONS"
SCP="scp $SSH_OPTIONS"
HOSTNAME=`GetHostName`
HMCOUTDIR=${MainOutDir}/$HOSTNAME/fsm.d
case $# in
  1)	querytype="aa"
	hmcname="$1"
	;;
  2)	querytype="$1"
	hmcname="$2"
	;;
  *)	usage; exit 1
	;;
esac
CMDNAME=`basename $0`
out "Running $CMDNAME version $VERSION"
AcquireHMCInfo "$querytype" "$hmcname"
