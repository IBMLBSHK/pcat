#!/usr/bin/perl
#######################################################################
#
# Copyright(c) 2010 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Author:      Alan Robertson
# Support:              https://cs.opensource.ibm.com/projects/powercat
#
#######################################################################
#
#       A perl command to gather information from linux /proc and /sys
#       directories.
#
#######################################################################
#
#	We are going to try and read most of the ASCII part of /proc and /sys,
#	with some specific things being looked for for real processes.
#
#	On Linux, the concept of "/proc" which Sun introduced back in the late 80s
#	to represent process information has been extended significantly
#	(some say abused) to provide a huge variety of largely undocumented
#	information.  This information changes from release to release of the
#	system, and will be different between two systems configured differently.
#
#	A discussion about the stability of the /sys filesystem can be found here:
#		http://kerneltrap.org/Linux/Sysfs_Stability
#
#	The /proc filesystem acts as an interface to internal data structures
#	in the kernel. It can be used to obtain information about the system and
#	to change certain kernel parameters at runtime.
#
#	To deal with the some more dynamic issues (like hot plugging devices and
#	dynamically loadable kernel modules), things relating to devices are
#	and modules under the /sys directory which is organized inside the kernel
#	considerably differently from /proc (which is largely ad hoc).
#
#	Information about the AppArmor security facility is also mounted under
#	/sys/kernel/security
#
#	You can find descriptions of /proc and /sys in a variety of places.  Here
#	are some links for /proc:
#
#	Administer Linux on the fly -
#		Use the /proc filesystem to get a handle on your system (2003)
#		http://www.ibm.com/developerworks/linux/library/l-adfly.html
#
#	Access the Linux kernel using the /proc filesystem -
#		This virtual filesystem opens a window of communication between
#		the kernel and user space (2006)
#		http://www.ibm.com/developerworks/linux/library/l-proc.html
#
#	The Linux /proc Filesystem as a Programmers' Tool -
#		Manipulating all manners of runtime state information by using
#		file-level system calls and commands. (2005)
#		http://www.linuxjournal.com/article/8381
#
#	proc(5) man page -
#		process information pseudo-filesystem 
#		http://linux.die.net/man/5/proc
#
#	Discover the possibilities of the /proc directory (2008)
#		http://www.linux.com/feature/126718
#
#	Here are a few for /sys:  
#
#	"The sysfs Filessytem" - Patrick Mochel (OLS 2005 paper):
#	http://www.kernel.org/pub/linux/kernel/people/mochel/doc/papers/ols-2005/mochel.pdf
#
#	Wikipedia entry for sysfs:
#		http://en.wikipedia.org/wiki/Sysfs
#
#	Kernel sysfs usage documentation:
#		http://www.mjmwired.net/kernel/Documentation/sysfs-rules.txt
#
#	Presentation about how sysfs is used in z/TPF (with some general comments - 2007)
#	http://publib.boulder.ibm.com/infocenter/ieduasst/stgv1r0/topic/com.ibm.iea.ztpf_v1/ztpf/1.1z/Database/TPFUG_Apr_2007_DBDF_fse05.pdf
#
#
#	As an example, to find out if an ethernet is plugged in or not, read
#	"/sys/class/net/eth0/carrier", 0 means you're unplugged.  Replace
#	eth0 with the name of your ethernet device ;-)
#

$ProcDir="/proc";
$SysDir="/sys";
$PrintThePathActionSubroutine=0;

#
#	Candidate list of files to read for processes in /proc
#
$ProcessFileList="attr/current cmdline coredump_filter cwd cpuset fd io latency limits loginuid oom_adj oom_score root sched schedstat sessionid stat statm status wchan";

#
#	Trying to read these pathnames is a really bad idea - things hang when you do...
#
#	/proc/kallsysms is just large, and not very useful...
#
%PathsToAvoid = (
	'/proc/ppc64/rtas/error_log',	'1',
	'/proc/kcore',			'1',
	'/proc/kmsg',			'1',
	'/proc/kallsyms',		'1',
	'/proc/self',			'1',
	'/sys/kernel/debug',		'1',
);


#
#	Mapping of some pathnames and corresponding short descriptions
#
sub InputPriorityMap {
	while (<DATA>) {
		next if /^#/;
		chop if /\n$/;
		# PriorityMap is now an array of arrays...
		push(@PriorityMap, [split(/\t/,$_, 4)]);
	}
	local($j, $k);
#	for ($j=0; $j <= $#PriorityMap; ++$j) {
#		local($action, $transform, $pattern, $explanation) = @{$PriorityMap[$j]};
#	}
	CreatePathActionsub();
}
#
#	This somewhat confusing looking piece of code has a good reason to work like it does...
#	It generates a subroutine called PathAction which works like the one just after it,
#	except that it runs about 10 times faster than the commented-out version of PathAction
#
#	What we do here is generate the code for a version of PathAction in which all the
#	patterns to match are constants, which allows Perl to compile them once, and know
#	they're not going to change.  This speeds up the code by about a factor of 10.
#

sub CreatePathActionsub {
	$asub='sub PathAction {
	my($pathname) = @_;
	study $pathname;
';
	for ($j=0; $j <= $#PriorityMap; ++$j) {
		local($action, $transform, $pattern, $explanation) = @{$PriorityMap[$j]};
		$pattern =~ s/\//\\\//g;
		if (defined($explanation)) {
			$explanation =~ s/'/\\'/g;
			$asub .= "\tif (\$pathname =~/^$pattern/) {return ('$action', '$transform', '$explanation');}\n";
		}else{
			$asub .= "\tif (\$pathname =~/^$pattern/) {return ('$action', '$transform');}\n";
		}
		
	}
	$asub.="	return(\'other\');\n}\n";

	if ($PrintThePathActionSubroutine) {
		print "Here is the Action Sub:\n";
		print $asub;
	}
	local ($ret) = eval $asub;
	if ($@ ne "") {
		print "Eval OOPS: [$ret] [$@]\n";
		exit 1;
	}
}

#sub PathAction {
#	my($pathname) = @_;
#	study $pathname;
#	for ($j=0; $j <= $PriorityMap; ++$j) {
#		local($action, $transform, $pattern, $explanation) = @{$PriorityMap[$j]};
#		if ($pathname =~ /^$pattern/) {
#			return ($action, $transform, $explanation);
#		}
#	}
#	return ("other");
#}

#
#	Routine to grab the contents of a file (or a symlink) into memory
#
sub catfile {
	local ($filetocat) = @_;
	if (-l $filetocat) {
		return ("--> " . readlink($filetocat));
	}
	local($result, $readres, $readrc);
	if (defined($PathsToAvoid{$filetocat})) {
		return undef;
	}
	if (!defined(open(FHANDLE , "<$filetocat"))) {
		#print "Returning undef1: $filetocat\n";
		return undef;
	}
	$result="";
	do {
		$readrc = read(FHANDLE, $readres, 65536);
		if (defined($readrc)) {
			$result .= $readres
		}
	}while (defined($readrc) && $readrc > 0);
	close(FHANDLE);
	if (defined($readrc)) {
		return $result;
	}
	#print "Returning undef2: $filetocat\n";
	return undef;
}


#
#	Routine to grab the contents of a file and stash it away for later...
#
sub GrabSystemPath {
	local($path)= $_[0];
	local ($contents);
	$contents = catfile($path);
	#	Trim trailing NULLS and white space...
	$contents =~ s/[\000\s]+$//;
	if (is_ascii($contents)) {
		$FileHash{$path} = $contents;
		#print "Value: ", $FileHash{$path}, "\n";
	}
}

#
#	Is the string we're looking at ASCII?
#
sub is_ascii {
	local($s) = $_[0];
	local($ordspace, $char, $ordchar) = (ord(' '), undef, undef);
	
	foreach $char (split(//,$s)) {
		$ordchar = ord($char);
		if ($ordchar < $ordspace || $ordchar > 127) {
			if ($char =~ /\s/) {
				next;
			}
			#print "NOT ASCII due to [$char] [$ordchar]\n";
			return 0;
		}
	}
	return 1;
}

#
#	Extract the pid from a pathname (if it's a real process)
#
sub process_pid {
	local($path) = $_[0];
	if ($path =~ /^\/proc\/([0-9]+)/) {
		return ($1,$path);
	}else{
		return undef;
	}
}


#
#	Dump out a single-line item
#
sub dump_ascii_1line {
	my ($label, $line, $explanation) = @_;
	if (defined($explanation)) {
		print $label, " = [", $line, "] # $explanation\n";
	}else{
		print $label, " = [", $line, "]\n";
	}
}
#
#	Dump out a multi-line item
#
sub dump_ascii_multi_line {
	my ($label, $value, $explanation) = @_;
	if (defined($explanation)) {
		print "========= [$label] [$explanation]=========\n$value\n";
	}else{
		print "========= [$label] =========\n$value\n";
	}
	print "=========\n";
}

sub do_transformation {
	my ($line, $transform) = @_;


	my(@lines)= split(/\n/, $line);
	my(@transforms)= split(/:/, $transform);

	for $t (@transforms) {
		if ($t eq "sort") {
			my($j);
			@lines = sort @lines;
		}
		if ($t eq "hidedates") {
			for ($j=0; $j <= $#lines; ++$j) {
				$lines[j] =~ s%\d\d?[-/]\d\d?[-/]\d\d?%YY/MM/DD%g;
			}
		}
		if ($t =~ /^s[%\/]/) {
			for ($j=0; $j <= $#lines; ++$j) {
				eval "\$lines[$j] =~ $t;";
			}
		}
	}
	return join("\n", @lines);
}


#
#	Dump out a line - one way or the other
#
sub dump_ascii {
	my ($label, $line, $transform, $explanation) = @_;
	if (defined($transform) && $transform ne "") {
		$line = do_transformation($line, $transform);
	}
	if ($line =~ /\n/){
		dump_ascii_multi_line($label, $line, $explanation);
	}else{
		dump_ascii_1line($label, $line, $explanation);
	}
}


#
#	Grab the information we're interested in for this /proc process
#
sub GrabProcessInfo {
	local ($pid) = $_[0];
	local($desireddir)=$ProcDir . "/" . $pid;
	local($path, $key);

	foreach $file (split(/ /,$ProcessFileList)) {
		local($path);
		$path=$desireddir . "/" . $file;
		#system("echo $path;" . " cat ".  $desireddir . "/" . $file);
		Grab_ProcLikeFile($path);
	}
}

#
#	Grab the information for a /proc or /sys-like file
#		We handle links and directories too...
#
sub Grab_ProcLikeFile {
	my ($path) = @_;
	return if defined($PathsToAvoid{$path});
	if (-d $path && ! -l $path) {
		opendir(PROCLIKEDIR, $path) || return;
		my(@ProcFiles) = grep(!/^\.\.?$/, readdir(PROCLIKEDIR));
		closedir(PROCLIKEDIR);
		foreach $file (@ProcFiles) {
			Grab_ProcLikeFile($path . "/" . $file);
		}
	}else{
		GrabSystemPath($path);
		return;
	}
}

#
#	Grab everything from /proc - treating real processes differently
#
sub Grab_Slash_Proc {
	opendir(PROCDIR, $ProcDir) || die("Can't open $ProcDir");
	my(@ProcFiles) = grep(!/^\.\.?$/, readdir(PROCDIR));
	closedir(PROCDIR);

	foreach $file (@ProcFiles) {
		my ($path) = $ProcDir . "/" . $file;
		my ($pid, $extra) = process_pid($path);
		if ($pid > 0) {
			GrabProcessInfo($pid);
		}else{
			Grab_ProcLikeFile($path);
		}
	}
}

#
#	Grab everything from a /proc-like directory (probably /sys)
#
sub Grab_ProcLike {
	my ($dirpath) = @_;
	opendir(PROCLIKEDIR, $dirpath) || return;
	my(@ProcLikeFiles) = grep(!/^\.\.?$/, readdir(PROCLIKEDIR));
	closedir(PROCLIKEDIR);
	foreach $file (@ProcLikeFiles) {
		Grab_ProcLikeFile($dirpath . "/" . $file);
	}
}

sub bypid {
	return (int($a) <=> int($b));
}

#
#	Print out all the information we have on processes
#
sub PrintProcessInfo {
	foreach $key (sort(keys(%FileHash))) {
		($pid,$path)=process_pid($key);
		if (defined($pid)) {
			if (defined(${GlobalPidList{$pid}})) {
				${$GlobalPidList{$pid}}{$path}=1;
			}else{
				my (%foores) = ($path, 1);
				$GlobalPidList{$pid} = \%foores;
			}
		}
	}
	foreach $pid (sort bypid keys(%GlobalPidList)) {
		foreach $path (sort(keys(%{$GlobalPidList{$pid}}))) {
			dump_ascii($path, $FileHash{$path});
		}
	}
}
#
#	Print out all out non-process information
#
#	The argument is optional and consists of either a pattern
#	or a pattern preceded by a "!" character.
#
#	If you give it a pattern, then only paths that match will be printed.
#	If you give it a "!pattern" argument, then only paths that DON'T match
#	will be printed.
#
#	If you omit the pattern, then all non-process information will be printed.
#
sub PrintNonProcessInfo {
	my ($pattern, $type) = @_;
	my ($wantamatch) = 1;

	# Did they specify ! in front of the pattern?
	if ($pattern =~ /^!(.*)/) {
		# Yup. Strip it from the pattern and remember that they
		# only want lines that _don't_ match.
		$wantamatch = 0;
		$pattern = $1;
	}

	foreach $key (sort(keys(%FileHash))) {
		my($match) = 0;

		# See if this pathname matches the given pattern.
		if ($key =~ /$pattern/i) {
			$match = 1;
		}

		#	Is this path one of the ones we want?
		if (($match && $wantamatch) || (!$match && !$wantamatch)) {

			# If this is a real process, we don't want it
			($pid,$path)=process_pid($key);
			if (!defined($pid)) {

				local($action, $transform, $explanation) = PathAction($key);
				# Only obey transformations for the "compare" operation
				if ($type ne "compare") {
					$transform="";
				}

				# If it's not one of the specified type, ignore it...
				if (!defined($type) || $action eq $type) {
					dump_ascii($key, $FileHash{$key}, $transform, $explanation);
				}
			}
		}
	}
}


InputPriorityMap();

Grab_Slash_Proc();			# Get everything from /proc
Grab_ProcLike($SysDir);			# Get everything from /sys

print "Cluster Comparable Items: These items should match across a cluster [",int(rand(100000)),"]\n";
PrintNonProcessInfo(".", "compare");	# Stuff that has to compare equal
print "End of Cluster Comparable Items [",int(rand(100000)),"]\n";

print "\n\nIBM-specific information ==============================================================\n";
PrintNonProcessInfo("ibm|ppc|PowerPC|fw-");# Print IBM-specific information

print "\n\nInformation we should look at =========================================================\n";
PrintNonProcessInfo("", "examine");	# Print other things we should look at

print "\n\nNON-IBM-specific information ==========================================================\n";
PrintNonProcessInfo("!ibm|ppc|PowerPC|fw-");	# Print non-IBM-specific information

print "\n\nInformation on Processes ==============================================================\n";
PrintProcessInfo();			# Print information about processes
__END__
#
#	Mapping of filename patterns and explanations
#	Note that the fields must be separated a tab (not a space).
#	These patterns are considered to be anchored.
#	If more than one pattern matches, only the first will be used.
#
#	The "Transformation" field is a series of transformations separated by ":" characters.
#	These transformations are only performed when we're producing the output for comparision.
#	The currently supported transformations include:
#		sort		sort the items in this entry
#		s/.../.../	perform the indicated substitution
#		s/.../.../g	perform the indicated substitution globally on each line
#		s%...%...%	perform the indicated substitution
#		s%...%...%g	perform the indicated substitution globally on each line
#		hidedates	substitute recognized dates into YY/MM/DD
#
#		If you really _must_ use a ":" in a pattern for substitution,
#		you can use \072 or \x3a instead
#
#
#Comparable	Transformation	Pattern	Explanation
#
#
compare		/proc/cmdline	boot options
compare		/proc/cpuinfo	type of CPU(s) and their characteristics
compare		/proc/devices	list of supported device majors
other		/proc/diskstats	Disk I/O statistics for each configured disk device.
compare		/proc/biosversion	version of BIOS installed
compare		/proc/nvram	information from BIOS nvram
other		/proc/rtc	Real time Clock chip information
compare	sort	/proc/filesystems	types of filesystems supported by this kernel at the moment
other		/proc/kallsyms	list of kernel symbols and their values (what is where in kernel memory)
examine		/proc/loadavg	system load average
examine		/proc/meminfo	information about memory usage from the kernel's perspective
compare		/proc/misc	minor devices of 'misc' device - each is independent.
compare	sort:s/ *[,-]? Live.*/ TRUNCATED/	/proc/modules	dynamically loaded modules
compare		/proc/partitions	list of major/minor numbers, sizes and mappings into device names
compare		/proc/scsi/scsi	list of attached disks and their types
examine		/proc/stat	general system statistics
compare	sort:s/\t[^\t]*\t[^\t]*$/ TRUNCATED/	/proc/swaps	list of swap devices, usage and characteristics
examine		/proc/uptime	how long the system has been up (in seconds)
compare		/proc/version	detailed Linux kernel version information
examine		/proc/vmstat	information given out by vmstat command
compare		/proc/ys/fs/aio-max-nr	maximum number of async I/O operations outstanding
examine		/proc/sys/fs/aio-nr	current number of async I/O operations outstanding
compare		/proc/sys/fs/file-max	Maximum number of open files
examine		/proc/sys/fs/file-nr	Current number of open files
examine		/proc/sys/fs/inode-nr	Current number of inodes
compare		/proc/sys/fs/suid_dumpable	1 if setuid programs can produce core dumps
compare		/proc/kernel/core_pattern	printf-style pattern for formatting core file names
compare		/proc/kernel/core_uses_pid	include pid in core file name?
compare		/proc/kernel/domainname	domain name part of FQDN
examine		/proc/kernel/hostname	system host name, `hostname` aka `uname -n`
compare		/proc/kernel/msgmax	Max size of a single SysV message
compare		/proc/kernel/msgmnb	Max # of bytes in a single SysV message queue
compare		/proc/kernel/msgmni	Max # of SysV message queues
compare		/proc/kernel/sem	SysV semaphore config - SEMMSL: The maximum semas per set; SEMMNS: max # of system semas; SEMOPM: The max # of ops allowed in a semop(2) call;  SEMMNI - Max # of sema ids in system
compare		/proc/kernel/shmall	Total memory for all SysV shared memory segments - should be at least ceil(shmmax/PAGE_SIZE).
compare		/proc/kernel/shmmax	maximum size of a SysV shared memory segment
compare		/proc/kernel/shmmni	maximum number of SysV shared memory segments
compare		/proc/kernel/tainted	1 if kernel is running any binary (non-open-source) modules
compare		/proc/kernel/osrelease	kernel version - uname -r
other		/net/arp	ARP table
examine		/net/dev	netstat -i style device statistics
other		/net/netstat	verbose network statistics
other		/net/unix	local IPC socket information
other		/net/tcp	active TCP connection information
examine		/sys/devices/[^/]*/net/[^/]*/statistics/.*_errors	networking error count (should be low)
examine		/sys/class/net/[^/]*/statistics/.*_errors	networking error count (should be low)
examine		/sys/class/net/[^/]*/carrier	1 if this network interface is connected
examine		/sys/devices/[^/]*/net/[^/]*/carrier	1 if this network interface is connected
compare		/net/sys/net/ipv4/netfilter/	firewall-related configuration
compare		/net/sys/net/ipv[46]/conf/
compare		/net/sys/net/ipv[46]/tcp_
compare		/net/sys/net/ipv[46]/udp_
compare		/net/sys/net/netfilter/	firewall-related configuration
