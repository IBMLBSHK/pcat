#######################################################################
#
# Copyright(c) 2010 - 2018 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Authors:     Alan Robertson, Bernhard Buehler
# Co-Author:		
# Support:              
#
#######################################################################
#
#	This is the README for the IBM STG Lab Services data collection tool (PCAT).
#
#######################################################################

Syntax (pcat.sh)
	
	pcat.sh [-h | --help | -?] [-c {counter}] [-d {output directory}] [--debug ] [-e {all | net,perf,rsct,sec}] [--force-ssh] [--hmc {IP-Address | IP-Label}] [-i {interval}] [--id {hmc-user-id}] [--nmon {all | large | last | two}] [--nohmc] [--nofsm] [--nomds] [--notsm] [--noos] [--noprompts] [--maketar] [--noinstallkey] [--pv|--PowerView] [--site {site name}] [--snap] [-V] [aa | nr]

Requirements:
	You need to run our scripts as root on AIX
	  - It may be able to run it without root but this will have some limitations, 
            see details below. 
	You have to know the hscroot password for your HMCs or an equivalent id
	If you're running TSM, you have to know the TSM login and password
	!! IMPORTANT !!
	If you are using XIV make sure that the tool is not collecting XIV
	data from the same XIV at the same time from multiple systems (LPARs)

The basic directions are:
	- tar -xvf pcat-install-version.tar
	- cd pcat
	- (optional) download the catalog.mic file (more details below under "Collecting invscout data"
	- ./pcat.sh

The result of each invocation will be an output tar.gz file.  If the machine
you're running it on is called fred, the output file will be named fred.tar.gz
(or fred.tar if gzip isn't available)

Please provide the output .tar.gz (or .tar) files back to the IBM consultant
performing the engagement.

The parameter aa is optional it will be added automatically if no parameter is defined
The parameter nr is optional is need to be used when the script can not be executed as root

This script will gather the following data:
	- data from the HMCs that support this LPAR
		to suppress this invoke it with the option --nohmc
			./pcat.sh --nohmc
	  For each HMC it wants to talk to you will have to supply the
		password for the hscroot account on it - twice
	- data from the current OS
		to suppress this, invoke it with the option --noos
			./pcat.sh --noos

==============================================================================

== BASIC USAGE ===============================================================
The simplest way to use the toolkit is just to invoke it as:
	./pcat.sh
	or
	./pcat.sh aa
	or
	/<path>/pcat/pcat.sh 

To get the current usage message, invoke it with the --help flag:
	./pcat.sh --help

When using the tool on Linux you may have no direct access to root. In such cases 
you you can make use of sudo.
	sudo ./pcat.sh 

==============================================================================

== SPEEDING THINGS UP A LITTLE ===============================================
If you want to speed up the data collection process a little, you can follow
the directions below.


Please run the script without any arguments once on each system (frame) in the
assessment, and for each subsequent LPAR on the same system (frame), run it with 
the --nohmc flag.
	For the first LPAR in a frame:
		pcat.sh
	For subsequent LPARS on the same frame:
		pcat.sh --nohmc

The --nofsm flag is an alias to the --nohmc flag. Therefore it has the same behavior.
It got added to not confuse customers who are using a FSM.

If you have TSM installed on these LPARs, you only need to collect TSM data once.
The --notsm flag will suppress collecting the TSM data.
	The first LPAR in the assessment that has TSM client software installed:
		pcat.sh
	The first LPAR on each of the other frames in the assessment
		pcat.sh --notsm
	Subsequent LPARS on any frame:
		pcat.sh --nohmc --notsm


==============================================================================

== Using the nr parameter ====================================================
The nr parameter should only be used for very special cases. If this parameter is used the 
tool will not check if the user-id root is used for execution. As a consequence of this you will 
get a lot of permission errors in the output files.
The simplest way to use the toolkit in this case is:
	./pcat.sh nr

Keep in mind the tool is written to be executed by root

==============================================================================

== Collecting invscout data ==================================================
To collect invscout (Inventory Scout) data you must download the latest catalog.mic file
to the "pcat" directory before you execute the pcat.sh script.
No other action needed. The tool will automatically collect the invscout date when it finds 
a catalog.mic file in the pcat directory.
The latest catalog.mic file can be found under http://techsupport.services.ibm.com/server/mdownload/catalog.mic 
Here examples how you might able to do it in an easy way.
# wget -q http://techsupport.services.ibm.com/server/mdownload/catalog.mic
# curl -get http://public.dhe.ibm.com/software/server/firmware/catalog.mic > catalog.mic

==============================================================================

== Using the "-e" option =====================================================
The -e option will collect additional data depending on the used arguments for this option.
Multiple arguments must be "," (comma) separated. Make sure you do not use any blank sign between the arguments
 - all 		The argument all is equal as if you would select all of the arguments allowed 

 - net 		The argument net will execute additional entstat commands with the -t option.
		This option may create error entries in the AIX ERROR log, if it finds an un-configured adapter. 
		This is not a problem at all but it can create confusion at the customer site.
		To get a list of affected commands use the following command in the pcat directory
		  # grep "^:net" *.txt 

 - perf		The argument perf will execute additionally two hpmstat commands. In some older AIX SPs 
		this caused unexpected AIX reactions. We could not find out which AIX SPs are affected. 
		It seems that it works fine on all AIX 7.1 Versions and also on the latest TLs of AIX 6.1. 
		To get a list of affected commands use the following command in the pcat directory
		  # grep "^:perf" *.txt

 - rsct		The argument rsct will execute additionally the command lsrsrc with the option -l for all
		found RSCT Resource Managers (RM).
		A resource listing of some of these RMs causes a start of an RSCT subsystem by the 
		AIX Systems Resource Controller. This does not create any problem on the OS or any Application.
		It just can create confusion at the customer site if the start of AIX subsystems gets monitored.
		To get a list of affected commands use the following command in the pcat directory
		  # grep "^:rsct" *.txt

 - sec 		The argument sec will execute additional commands to get more security related information.
		It's recommended to use this when you are performing a security related engagement.
		To get a list of affected commands use the following command in the pcat directory
		  # grep "^:sec" *.txt

==============================================================================

== Collecting data for PowerView =============================================
To collect the additional data for PowerView you need to use the -pv flag. The
--pv and --PowerView flag are identical. If just the --pv flag is used the default values 
for -c (10) times and the default for -i (60) sec. will be used. If you may want 
to use different values for -c or -i then the --pv flag is not needed in addition 
to one of these flags.

==============================================================================

== Using a different counter for PowerView ===================================
To use a different counter use -c <number>. This number will be used by iostat, 
vmstat, mpstat, and nmon. The default value is 10.
If -c is used the --pv flag will automaticaly be included.

==============================================================================

== Using a different interval for PowerView ==================================
To use a different interval (duration) use -i <number> (the number must be in seconds.
This number will be used by iostat, vmstat, mpstat, and nmon. The default value
is 60. If -i is used the --pv flag will automaticaly be included. 

==============================================================================

== Using the "--site" option =================================================
This option is to specify the "site name" where the system is located. It can be
used later for reporting and/or analysis seperation.

==============================================================================

== Collecting nmon data (topas) ==============================================
If you like to collect nmon data which are located in the default output directory
you can use the --nmon flag. This flag requires an argument which specifies how 
much files get collected.
	--nmon all	This will collect all the stored nmon files
	--nmon large	This will collect only the largest nmon file stored on your system
	--nmon last	This will collect the nmon file from yesterday
	--nmon two	This will collect the nmon file from yesterday and the largest one

==============================================================================

== Using the "--nomds" option ================================================
By default the tool does check for the existence of the catalog.mic file in the pcat directory.
As mentioned above it is optional. However the tool will prompt for a feed back if 
you like to continue or not.
The --nomds option does suppress this check.
==============================================================================

== Using the "--id" option ===================================================
If the default HMC admin id "hscroot" can not be used. You can use the --id option 
to define any id which has similar rights than hscroot.

==============================================================================

== Using the force option ====================================================
As usual using a force option should only be used if you are sure what you are doing !!
The --force-ssh might be used if you get a warning that there is no openssh installed.
And if you are sure that there will be no damage to the system and that the commands we use 
in our script does not break the customers environment.

==============================================================================

== Collecting hmc data from a UNIX system ====================================
If none of you LPARs has the capability to connect to the HMCs. Then you can run 
the pcat tool on a UNIX or LINUX system which has tcpip access to your HMCs. In this
case you have to use the --hmc flag. This flag requires an argument, which is 
either the TCP/IP address or the IP-name of the HMC.
When using the --hmc flag the flag --noos is automatically applied.

Example:	pcat.sh --hmc testhmc
		pcat.sh --hmc 10.10.11.5

==============================================================================

== Collecting fsm data from a UNIX system ====================================
If the systems are managed by a FSM instead of a HMC. Then you must specify
the --fsm and the --id flags. 
By default it does also collect the data of the local system. If you do not want this
you also must specify the --noos flag. 
You can run the pcat tool on a UNIX or LINUX system which has tcpip access to your FSM. 
In most cases the --fsm flag needs an argument. 

Example:	pcat.sh --fsm testfsm --id default
		pcat.sh --fsm 10.10.11.5 --id default
		pcat.sh --fsm testfsm --id default --noos

==============================================================================

== Using the "--snap" option =================================================
This option is only for AIX environments for Linux it will be ignored.
If it is used the system will also create a snap -gGfkLNc after the PCAT data collection.
The PCAT data is also added to the snap content. So it is just needed 
to upload or copy the snap file.  

==============================================================================

== Using the "-V" option =====================================================
This option does only return the current PCAT version.

==============================================================================


	Thanks!
