#######################################################################
#
# Copyright(c) 2010 - 2015 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Author:      Alan Robertson, Bernhard Buehler
# Co-Author:		
# Support:              buehlerb@de.ibm.com
#
#######################################################################
#
#       Common definitions for the powercat toolset.
#
#######################################################################
VERSION=6.1
MAXFILENAMELENG=50
HMC_UserID=hscroot
SH=/bin/sh
AUTHORIZED_KEYS=authorized_keys
SystemDir="Systems"
SystemHist="${SystemDir}_$(date +"%Y%m%dT%H:%M")"
# Defaults for settings for vmstat and so on.
StatSec=60
StatCount=10


#Hack for our test labs
case `uname -n` in
  ussteam0?-adm)	HMCID=powercare;;
esac

out() {
  printf '%s\n' "$*"
}

#
#	Where should we find our rule files, etc?
#
compute_startdir() 
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi 
  DirName=""
  case $0 in
   /*)		startdir=`dirname "$0"`;;
   */*)		DirName=$(dirname "$0")
		DirNameLengs=$(echo ${DirName} | wc -m)
                if [ ${DirNameLengs} -le 2 ]
                then 
                  startdir="`pwd`"
                else
                  if ( echo ${DirName} | grep -q '\.' )
                  then
                    startdir="$(pwd)/$(echo ${DirName} | cut -c3-)"
                  else
                    startdir="`pwd`/${DirName}"
                  fi
                fi;; 
   *)		startdir=`pwd`;;
  esac
  echo "$startdir" | sed -e 's%^\./%%' -e's%/\./%/%'  -e 's%[^/][^/]*/\.\./%/%g'
}

create_quoted_args() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  outstr=""
  for arg in "$@"
  do
    outstr="$outstr \"$arg\""
  done
  out "$outstr"
}

#
#	Make a command string into a file name
#	-	getting rid of characters that don't work in file names...
#
cmdnamefilter() {
	tr '\\\t\n $()[]{}=|<>&;:~/|#*"`~.' '______________________________'	\
	|	tr \' _								\
	|	tr -s '_-'							\
	|	sed -e	's%^_%%' -e 's%_$%%' -e 's%_txt$%%' -e 's%_-%-%g'	\
	-e		's%-[A-Z]%^&%g'      -e	's%\^-%-^%g'			\
	|	cut -c1-$MAXFILENAMELENG 2>/dev/null 				\
	|	sed 's%$%.txt%'
}

cmdtoname() {
  printf "%s\n" "$*" | cmdnamefilter
}

#
#       What should we call this OS?
#
compute_osclass() {
  OS=`uname -o 2>/dev/null | tr 'A-Z' 'a-z'`
  ret=$OS
  case $OS in
    *linux*)    OS=linux;;
    *aix*|"")   OS=aix;;
    *)          OS=`out $OS| tr 'A-Z' 'a-z'`;;
  esac
  out $OS
}

compute_architecture() {
  # AIX broke uname -m...  Sigh...
  # And most of the uname flags...
  case `compute_osclass` in
    aix)        out p; return 0;;
  esac
  ARCH=`uname -m | tr 'A-Z' 'a-z'`
  case $ARCH in
    *z*)                ARCH=z;;
    *power*|*ppc*)      ARCH=p;;
    i*86*|*86*)         ARCH=x;;
    *)                  ARCH=`uname -m | tr 'A-Z' 'a-z'`;;
  esac
  out $ARCH
}

compute_LXdistri()
{
  if [ "$OSCLASS" = "aix" ]
  then
    LXDist=""
  else
    LXDist=$(cat /etc/*release | grep -w ^ID 2>/dev/null | tr 'A-Z' 'a-z')
    if [ -z "${LXDist}" ]
    then
      # the ID information does not exist on older systems so we use anolder way to get details
      LXDist=$(cat /etc/issue 2>/dev/null | tr 'A-Z' 'a-z')
    fi
    case $LXDist in
      *ubuntu*)		LXDist="ubun" ;;
      *rhel*)		LXDist="rhel" ;;
      *red\ hat*)	LXDist="rhel" ;;
      *sled*)		LXDist="suse" ;;
      *suse*)		LXDist="suse" ;;
      *)		LXDist="" ;;
    esac
  fi
  out $LXDist
}


#	Not a very good host name, but better than randomness...
ipaddrname() {
  /sbin/ifconfig | grep 'inet addr:' | head -n 1 | sed -e 's%.* inet addr: *%%' -e 's% .*%%'
}
#
#	Our host-name-of-last-resort
#
uniquename() {
  if
    [ -f .saveuniquename ]
  then 
    cat .saveuniquename
    return 0
  fi
  out "localhost`date +%H%M%S`$RANDOM" | tee .saveuniquename
}

#
#	What's our hostname?
#	(hint:  We don't like localhost)
#
GetHostName() {
  Name=""
  for try in 'uname -n' 'hostname' 'ipaddrname' 'uniquename'
  do
    case $Name in
    	localhost|localhost.*|127.0.0*|"")
		Name=`$try 2>/dev/null | tr 'A-Z' 'a-z'`;;

	*)	break;;
    esac
  done
  out $Name
}
prefix_order() {
  cat <<-!
	$1
	$1-$OSCLASS
	$1-$OSCLASS-$LXDist
	$1-$ARCH
	$1-$ARCH-$OSCLASS
	$1-$ARCH-$OSCLASS-$LXDist
	!
}

assessment_files() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  prefix="$1"
  suffix="$2"
  basedir=${3-$BASEDIR}

  prefix_order "$prefix" |
  while
    read middle
  do
    if
      [ -f "$basedir/$middle-$suffix" ]
    then
      out "$basedir/$middle-$suffix"
    fi
  done
}

showprogress()
{
count=0
    while true; do
        sleep 5
        echo ".\c"
    done
}

endshowprogress()
{
    kill -9 $1
    echo ""
}

OSCLASS=`compute_osclass`
ARCH=`compute_architecture`
LXDist=$(compute_LXdistri)
