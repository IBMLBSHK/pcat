#!/bin/sh
#######################################################################
#
# Copyright(c) 2010 - 2018 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Author:      Alan Robertson, Bernhard Buehler
# Co-Author:		
# Support:              buehlerb@de.ibm.com
#
#######################################################################
#
#	Program for capturing OS data for assessments - of any kind...
#
#######################################################################
#
#
if [ "$PCATDEBUG" = "on" ]; then set -x; fi
ASSESSMENT=aa	#	Availability assessment
LANG=C; LC_ALL=C
export LANG LC_ALL
trap 'rm -f $FILENAMES $PRESENTSECTIONS $File2Link $GroupList' 0

usage() {
  cat <<-! >&2
	Script or usage    E R R O R
	You should never be here \!\!\!

	usage: $0 [assessment-type]
	$0 collects data for assessments and evaluations.
	You have to be root to collect this data.

	It supports an arbitrary number assessment-types, along with
	two OSes, and three architectures, and rule and extension files
	to go along with these combinations of attributes.

	The default assessment-type is 'aa'.
	The supported architectures are 'p', 'z' and 'x'.
	The supported OSes are 'AIX' and 'linux'
	Extension files are written in shell syntax, and are included using the '.' operator.
	These can be used to add new command/action/keywords for use in the command sets.

	Rule files must be provided for $0 to know what you want done, and end
	in the suffix "-cmds.txt"

	The following combinations of assessment, architecture and OS are supported for
	both extension and rule files.
		assessment, assessment-os, assessment-arch, and assessment-arch-os
	For the availability assessment on AIX, this would result in the following file names
		aa, aa-aix, aa-p, and aa-p-aix - in this order.

	Corresponding rule files would be named:
		aa-cmds.txt, aa-aix-cmds.txt, aa-p-cmds.txt, and aa-p-aix-cmds.txt
	and extension files named
		aa-ext.sh, aa-aix-ext.sh, aa-p-ext.sh, and aa-p-aix.ext.sh
	!
  exit 1

}
#
#	BUGS:
#	The TSM commands (dsmadmc, et al) need command substitution in order to work
#		We want to do something more general than the previous CADET did, yet which
#		is simple to interact with and hopefully simple to write rules for.
#

#
#	Check if we are root
#
areweroot() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  case `id` in
    *uid=0*|*euid=0*)	true;;
    *)			false;;
  esac
}

#
#	Our slightly fancier version of 'cat'
#
fileprint() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  for file
  do
    out "==== BEGIN Contents of $file ===="
    cat $file
    rc=$?
    out "==== END Contents of $file ===="
    return $rc
  done
}

#
# Replace leading : with extention directory name
#
extname()
{  
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if (echo $1 | grep -q "^:")
  then
    ExtOutName="ext/$(echo $1 | cut -c 2-)"
  elif (echo $1 | grep -q ":")
  then
    ExtOutName="$(echo $1 | awk -F ":" '{print $1}')"
  else
    ExtOutName="$1"
  fi
  echo ${ExtOutName}
}
#
#	What directory should these results go in?
#
areatodir() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  OutDir=$(extname $1)
  out "${MainOutDir}/`echo $HOSTNAME/${OutDir} | sed 's%  *%%' | tr 'A-Z' 'a-z'`"
}

#
#	Generate all our output file names from the commands we will run
#
shortfilenames() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if
    [ -s "$FILENAMES" ]
  then
    cat $FILENAMES
    return 0
  fi
  (eval cat $RULES) | grep -v '^#' |
  while
    read -r area cmd
  do
    if (echo ${area} | grep ":" | grep -vq "^:")
    then
#      FirstAreaName=$(echo ${area} | awk -F ":" '{print $1}')
      for RepCMD in $(echo ${area} | tr ":" " ")
      do
        out "`areatodir "${RepCMD}"`/`cmdtoname \"$cmd\"`"
      done
    else
      out "`areatodir "$area"`/`cmdtoname \"$cmd\"`"
    fi
  done | tee  $FILENAMES
}

catnames() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  (eval cat $RULES) | grep -v '^#' | cut -f1 |
  while
    read -r Cat
  do
    if (echo ${Cat} | grep ":" | grep -vq "^:")
    then
      for i in $(echo ${Cat} | tr ":" " ")
      do
        echo $i >> ${GroupList}
      done
    else
      echo ${Cat} >> ${GroupList}
    fi
  done
  cat ${GroupList} | sort -u
}

whichareasareinstalled() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  for area in `catnames`
  do
    if (echo ${area} | grep ":" | grep -vq "^:")
    then
      for Areas in $(echo ${area} | tr ":" " ")
      do
        test=`(eval cat $RULES) | grep -i "^##ISINSTALLED	${Areas}	" | head -n 1 | cut -f3-`
        if
          [ -z "$test" ]
        then
          out ${Areas}
        elif
          eval "( $test )"  > /dev/null 2>&1
        then
          out ${Areas}
        else
          echo "${Areas} does not appear to be installed"
        fi
      done
    else
      test=`(eval cat $RULES) | grep -i "^##ISINSTALLED	$area	" | head -n 1 | cut -f3-`
      if
        [ -z "$test" ]
      then
        out $area
      elif
        eval "( $test )"  > /dev/null 2>&1
      then
        out $area
      else
        echo "$area does not appear to be installed"
      fi
    fi
  done
}

#
#	Make sure our shortened file names will be unique...
#
lookfordups() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  dupcount=`shortfilenames | tr 'A-Z' 'a-z' | sort | uniq -d | wc -l`
  if
    [ "$dupcount" -gt 0 ]
  then
    out "OOPS!  We will create $dupcount duplicate filenames!"
    shortfilenames | tr 'A-Z' 'a-z' | sort | uniq -d
  fi
}
#
#	What is the list of categories our files go into?
#
category_names() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  catnames | 
  while
    read -r cat
  do
    CategoryName=$(extname $cat)
    if (echo ${cat} | grep ":" | grep -vq "^:")
    then
      cat="$(echo $1 | awk -F ":" '{print $1}')"
    fi
    if
      isSectionPresent "$cat"
    then
      out "	$(printf '%-9s' ${CategoryName})		`shortfilenames | grep -ic "/${CategoryName}/"` commands"
    else
      out "	$(printf '%-9s' ${CategoryName})		`shortfilenames | grep -ic "/${CategoryName}/"` commands (skipped)"
    fi
  done
  out "	TOTAL			`shortfilenames | grep -c .` commands"
}

#
#	Run a command - and log and label the output
#
runcmd() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  dir="$1"
#  cmd="$(echo $@ | cut -d " " -f2-)"
  outdir=`areatodir "$dir"`
  test  ! -d "$outdir" && mkdir -p "$outdir"
  outfile="$outdir/`cmdtoname "$cmd"`"
  
  # tail -512000 is used to limit the output files to about 100MB
  (
    cat > "$outfile" 2>&1 <<-!EndCat
	==== This output can be found in $outfile ====
	==== START $cmd `date` ====
	!EndCat
    eval "( $cmd | tail -512000
          )"  >>  "$outfile" 2>&1 </dev/null
    rc=$?
    cat >> "$outfile" 2>&1 <<-!EndCat2
	==== EXITED with rc $rc ====
	==== END $cmd `date` ====
	!EndCat2
  ) </dev/null

}

#
#	Do as we're told...
#
obeydirectives() 
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  (eval cat $RULES) | grep -v '^#' |
  while
    read -r dir cmd
  do
    if (echo ${dir} | grep ":" | grep -vq "^:")
    then
      FirstAreaName=$(echo ${dir} | awk -F ":" '{print $1}')
      Dir2Link=$(echo ${dir} | cut -d ":" -f2-)
      for Tasks in $(echo ${Dir2Link} | tr ":" " ")
      do
#        if
#          isSectionPresent "${Tasks}"
#        then
          echo "${FirstAreaName}:${Tasks}:${cmd}" >> ${File2Link}
#        fi
      done
      echo "$(date +"%Y/%m/%d %H:%M:%S") : Command : $cmd" >> $ExecutionLogFile
      BGcmd=$(echo $cmd | awk '{print $NF}')
      echo $BGcmd | grep "&" > /dev/null 
      RC_BGcmd=$?
      if [[ "$BGcmd" = "&" || $RC_BGcmd -eq 0 ]]
      then
        case ${FirstAreaName} in
          \#*)	;; 
          *)	cmdBG=$(echo $cmd | awk -F \& '{print $1}') ;
		export cmd="$cmdBG" ;
		runcmd "${FirstAreaName}" "$cmdBG" & ;;
        esac
      else
        case ${FirstAreaName} in
          \#*)	;; 
          *)	export cmd ;
		runcmd "${FirstAreaName}" "$cmd" ;;
        esac
      fi
    else
      if
        isSectionPresent "$dir"
      then
#        execdirectives ${dir} ${cmd}
        echo "$(date +"%Y/%m/%d %H:%M:%S") : Command : $cmd" >> $ExecutionLogFile
        BGcmd=$(echo $cmd | awk '{print $NF}')
        echo $BGcmd | grep "&" > /dev/null 
        RC_BGcmd=$?
        if [[ "$BGcmd" = "&" || $RC_BGcmd -eq 0 ]]
        then
          case $dir in
            \#*)	;; 
            *)		cmdBG=$(echo $cmd | awk -F \& '{print $1}') ;
			export cmd="$cmdBG" ;
			runcmd "$dir" "$cmdBG" & ;;
          esac
        else
          case $dir in
            \#*)	;; 
            *)		export cmd ;
			runcmd "$dir" "$cmd" ;;
          esac
        fi
      fi
    fi
  done
  if [ -s ${File2Link} ]
  then
    ActualDir=$(pwd)
    cat ${File2Link} |
    while 
      read -r LinkToCreate
    do
      cd ${BASEDIR}
      LnSource=$(echo ${LinkToCreate} | cut -d ":" -f1)
      LnTarget=$(echo ${LinkToCreate} | cut -d ":" -f2)
      LnCMD=$(echo ${LinkToCreate} | cut -d ":" -f3-)
      if [ -d $(areatodir ${LnTarget}) ]
      then
        cp -p $(areatodir ${LnSource})/$(cmdtoname ${LnCMD}) $(areatodir ${LnTarget})/$(cmdtoname ${LnCMD})
        echo "$(date +"%Y/%m/%d %H:%M:%S") : Copy : $(cmdtoname ${LnCMD}) to $(areatodir ${LnTarget})" >> $ExecutionLogFile
#        ln $(areatodir ${LnSource})/$(cmdtoname ${LnCMD}) $(areatodir ${LnTarget})/$(cmdtoname ${LnCMD})
#        echo "$(date +"%Y/%m/%d %H:%M:%S") : Link : $(cmdtoname ${LnCMD}) to $(areatodir ${LnTarget})" >> $ExecutionLogFile
      fi
    done
    cd ${ActualDir}
  fi
}


#
#	Tell them our circumstances
#
summarize_init() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  out "Running $0 version $VERSION on $HOSTNAME for OS $OSCLASS"
  if
    [ -z "$EXTENSIONS" ]
  then
    out "No extensions enabled."
  else
    out "Enabling extensions in $EXTENSIONS"
  fi
  out "Using command sets found in $RULES"
  out "List of analysis categories:"
  category_names
  out "	(most of these take about seconds or up to a minute each depending on system load and command used)"
}

#
#
#
isSectionPresent() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if
    [ -z "`head -n 1 < $PRESENTSECTIONS`" ]
  then
    whichareasareinstalled > $PRESENTSECTIONS
  fi
  if
    grep -i "^$1$" $PRESENTSECTIONS >/dev/null
  then
    true
  else
    false
  fi
}

get_cluster_name()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  Return_Info="#"
  ClusterProd="No"
  case "$OSCLASS" in
    "aix")	if ( lslpp -L cluster.es.server.rte > /dev/null 2>&1 )
		then
		  ClusterProd="PowerHA"
		fi
		if ( lslpp -L sam.core.rte > /dev/null 2>&1 )
		then
		  ClusterProd="TSA"	
		fi
                if ( lslpp -L VRTSvcs > /dev/null 2>&1 )
		then
		  ClusterProd="Veritas"	
		fi
                if [ "${ClusterProd}" = "No" ]
                then
                  if (lslpp -l bos.cluster.rte > /dev/null 2>&1 )
                  then
                    if (lscluster -c > /dev/null 2>&1)
                    then
                      ClusterProd="CAA"
                    fi
                  fi
                fi

		case "$ClusterProd" in
		  "PowerHA")	CLUSTER_NAME=$(/usr/es/sbin/cluster/utilities/clvt query cluster 2> /dev/null | grep CLUSTER_NAME | awk -F \" '{print $2}')
    		  		Return_Info="Cluster=$CLUSTER_NAME"
				;;
		  "TSA")	CLUSTER_NAME=$(lsrpdomain | grep -v Name | awk '{print $1}')
				Return_Info="Cluster=$CLUSTER_NAME"
				;;
		  "Veritas")	CLUSTER_NAME="$(grep -i "^cluster" /etc/VRTSvcs/conf/config/main.cf 2> /dev/null | awk '{print $2}')"
				Return_Info="Cluster=$CLUSTER_NAME"
				;;
		  "CAA")	CLUSTER_NAME=$(lscluster -c | grep "Cluster Name" | awk '{print $3}')
				Return_Info="Cluster=$CLUSTER_NAME"
				;;
		  *)		CLUSTER_NAME="#"
				;;
		esac
		;;
    "linux")	true ;;
    *)		true ;;
  esac
  echo $Return_Info
}

get_role_name()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  Return_Info="#"
  case "$OSCLASS" in
    "aix")	if [ -f /usr/ios/cli/ioscli -a -x /usr/ios/cli/ioscli ]
		then
		  Return_Info="Role=VIO"
		fi
                if [ -f /etc/oratab ]
                then
                  Return_Info="Role=Oracle DB"
                fi
		;;
    "linux")	true ;;
    *)		true ;;
  esac
  echo $Return_Info
}

get_site_name()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  Return_Info="#"
  if [[ -n "${FlagSiteName}" ]]
  then
    Return_Info="Site=${FlagSiteName}"
  else
    case "$OSCLASS" in
      "aix")	if ( lslpp -L cluster.es.server.rte > /dev/null 2>&1 )
		then
		  L_Node="$(/usr/es/sbin/cluster/utilities/get_local_nodename)"
                  Site_Name="$(/usr/es/sbin/cluster/utilities/cllssite -cn | grep ${L_Node} | awk -F : '{print $2}')"
                  if [[ -n "${Site_Name}" ]]
                  then
                    Return_Info="Site=${Site_Name}"
                  fi
		fi
		;;
      "linux")	true ;;
      *)	true ;;
    esac
  fi
  echo $Return_Info
}

create_os_info()
{
  echo "OS_Group:OS:Platform:Site" > ${MainOutDir}/${HOSTNAME}/OS_Info.txt
  case "$OSCLASS" in
    "aix")	if [ -f /usr/ios/cli/ioscli -a -x /usr/ios/cli/ioscli ]
		then
		  OutText="AIX:VIO:"
		else
		  OutText="AIX:AIX:"	
		fi
       		;;
    "linux")	LX_Type=$(compute_LXdistri)
		if [ "${LX_Type}" = "ubun" ]
		then
		  OutText="Linux:ubuntu:"
		else
		  OutText="Linux:${LX_Type}:"
		fi
		;;
    *)		true ;;
  esac 
  case "${ARCH}" in
    p)		OutText="${OutText}Power:"
		;;
    x)		OutText="${OutText}Intel:"
		;;
    *)		true ;;
  esac
  if [ FLAG_PV -eq 1 ]
  then
    OutText="${OutText}${FlagSiteName}"
  else
    OutText="${OutText}$(get_site_name)"
  fi
  echo ${OutText} >> ${MainOutDir}/${HOSTNAME}/OS_Info.txt
}


##########################################################################
# main
##########################################################################
if [ "$PCATDEBUG" = "on" ]; then set -x; fi

# BASEDIR=`compute_startdir`
. $BASEDIR/commonpcatdefs.sh


if
  [ $# -eq 1 ]
then
  ASSESSMENT=`out "$1" | tr 'A-Z' 'a-z'`
elif 
  [ $# -gt 1 ]
then
  usage "$0"
fi

# HOSTNAME=`GetHostName`
STARTDIR=`compute_startdir "$@"`
OSCLASS=`compute_osclass`
ARCH=`compute_architecture`
CMD=`basename $0`
OUTFILE=${MainOutDir}/$HOSTNAME/`out $CMD| sed 's%\.%_%g'`-out.txt
export HOSTNAME STARTDIR OSCLASS

ExecutionLogFile="${MainOutDir}/$HOSTNAME/Exec.log"

#	Enable extensions (if any) first...
#	Look for various kinds of extensions...
EXTENSIONS=""
for prefix in `prefix_order "$ASSESSMENT"`
do
  EXTENSION="$STARTDIR/$prefix-ext.sh"
  if
    [ -f "$EXTENSION" -a -r "$EXTENSION" ]
  then
    out "Including extensions from $EXTENSION" | tee -a $OUTFILE
    . "$EXTENSION"
    case $EXTENSIONS in
      "")	EXTENSIONS=$EXTENSION;;
      ?*)	EXTENSIONS="$EXTENSION $EXTENSION";;
    esac
  fi
done
PRESENTSECTIONS=`mktemp`
File2Link=`mktemp`
cat /dev/null > ${File2Link}
GroupList=`mktemp`
cat /dev/null > ${GroupList}
FILENAMES=""
if
  [ -z "$FILENAMES" ]
then
  FILENAMES=`mktemp`
fi
export FILENAMES File2Link GroupList

RULES=""
for prefix in `prefix_order "$ASSESSMENT"`
do
  RULE="$STARTDIR/$prefix-cmds.txt"
  if
    [ -f "$RULE" -a -r "$RULE" ]
  then
    case $RULE in
      "")	RULES=\"$RULE\";;
      ?*)	RULES="$RULES \"$RULE\"";;
    esac
  fi
done

if [ $FLAG_noroot -eq 0 ]
then
  if
    areweroot
  then
    : Cool!  It-s good to be the king.
  else
    out "ERROR: $0 must be run as root." >&2 | tee -a $OUTFILE
    exit 1
  fi
fi

if
  [  -z "$RULES" ]
then
  out "Cannot find any $ASSESSMENT engagement command sets for architecture $ARCH OS $OSCLASS " >&2 | tee -a $OUTFILE
  exit 1
fi

export ClusterName="$(get_cluster_name)"
export RoleName="$(get_role_name)"
export SiteName="$(get_site_name)" 

test  ! -d "${MainOutDir}/$HOSTNAME" && mkdir -p "${MainOutDir}/$HOSTNAME"
(
  out "PCAT tool started using: ${PCAT_Input}"
  lookfordups
  summarize_init
  out "Beginning $OSCLASS host data collection for $ASSESSMENT on $HOSTNAME at `date`"
  if
    [ -f ${MainOutDir}/$HOSTNAME/extrainfo.txt ]
  then
    rm ${MainOutDir}/$HOSTNAME/extrainfo.txt
  fi
    cat <<-! >${MainOutDir}/$HOSTNAME/extrainfo.txt
	#
	#	This is the extrainfo.txt file - you need to update it by hand.
	#	Things you put in here are used by the analysis tool to tell it things you'd
	#	like for the tool use in reports.  Anything you put in here will go in the
	#	server table for the report.
	#	Things you might want to put in here include:
	#	RAID=RAID level
	#	Role=Web Server
	#	Site=Mexico
	#	Cluster=SAP Cluster
	#		Cluster is special to the analysis tool
	#		and will be used for doing consistency checking.
	#		If this machine belongs to a cluster you should indicate that in this file.
	${ClusterName}
	${RoleName}
	${SiteName}
	!
  # fi
  create_os_info
  echo "Start of OS data collection PCAT version $VERSION $(date)" > $ExecutionLogFile
  echo "-------------------------------------------------------------------------------" >> $ExecutionLogFile
  obeydirectives
  echo "Check if there are still background jobs running and wait for them" >> $ExecutionLogFile
  jobs -l >> $ExecutionLogFile 2>&1
  wait
  echo "$(date +"%Y/%m/%d %H:%M:%S") data collection finished" >> $ExecutionLogFile
  out "Ending $OSCLASS host data collection for $HOSTNAME at `date`"
  out "Log of this output can be found in $OUTFILE"
) 2>&1 | tee -a $OUTFILE
