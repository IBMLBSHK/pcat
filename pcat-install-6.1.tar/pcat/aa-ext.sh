#######################################################################
#
# Copyright(c) 2010 - 2018 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Author:      Alan Robertson, Bernhard Buehler
# Co-Author:		
# Support:              
#
#######################################################################
#
#	Functions made available to all (aa) availability assessments
#       on all architecures, all OSes
#
#######################################################################
#
if [ "$PCATDEBUG" = "on" ]; then set -x; fi

# PATH information for Veritas
PATH=$PATH:/sbin:/usr/sbin
PATH=$PATH:/opt/VRTSvcs/bin
PATH=$PATH:/usr/lpp/mmfs/bin
# PATH information for RSCT
PATH=/opt/rsct/bin:$PATH
# PATH information for local/bin which may be used by some applications like DB2
PATH=$PATH:/usr/local/bin
export PATH

IsTSMLoaded() {
#  test -f /usr/tivoli/tsm/client/ba/bin/dsm.opt   # original test command
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  test -f /usr/bin/dsmadmc

}

#
# The TSM admin id and password must be in the shell environment
# (TSMADMID / TSMADMPASS) for the TSM function to work...
#
##PROMPTFOR	FLAG_notsm	IsTSMLoaded	TSMADMID 	TSM Login name
##PROMPTFOR	FLAG_notsm	IsTSMLoaded	TSMADMPASS	TSM Login password
#
TSM() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if
    test -z "$TSMADMID"
  then
    out "Skipping TSM "$@" command - no TSM id in environment"
    return 1
  else
    dsmadmc -id="$TSMADMID" -pass="$TSMADMPASS"  -displaymode=list q "$@"
  fi
}

list_ldd()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  for i in $(ls -l $1/* | grep '^-' | awk '{print $NF}')
  do
    file $i | grep -q script
    RC_FileType=$?
    if [ $RC_FileType -eq 1 ]
    then
      echo "---------------- ldd $i ----------------"
      ldd $i
      echo ""
    fi
  done
}

get_mm_device()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  echo $(mmlsmgr | egrep -v "^Cluster|----|^file" | awk '{print $1}')
}

print_gpfs_LocalMountOpt()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  LocalMountOptions=$(ls /var/mmfs/etc/localMountOptions*)
  RC_LMO=$?
  if [ ${RC_LMO} -eq 0 ]
  then
    out "Local Mount Options found"
    out "details are listed in:"
    for LMO in ${LocalMountOptions}
    do
      out "${MainOutDir}/${HOSTNAME}/gpfs/fileprint_${LMO}.txt"
      fileprint ${LMO} > ${MainOutDir}/${HOSTNAME}/gpfs/fileprint_${LMO}.txt
    done
  else
    out "\"No\" Local Mount Options found"
  fi
}

