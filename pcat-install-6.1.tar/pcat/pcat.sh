#!/bin/sh
#######################################################################
#
# Copyright(c) 2010 -2018 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Author:      Alan Robertson, Bernhard Buehler
# Co-Author:		
# Support:              buehlerb@de.ibm.com
#
#######################################################################
#
#       Program to gather HMC and OS data for any type of assessment.
#
#######################################################################
#
#set -x
export PCATDEBUG="off"
set +x
for i in $@
do
  if [ "$i" = "--debug" ]
  then
    set -x
    export PCATDEBUG="on"
    break
  fi
done

#
usage() {
  cat <<-! >&2
	usage: $0 [flags] [assessment-type]
	$0 collects HMC and/or OS data for assessments and evaluations.

	Supported flags include these:
	  -V				         It returns the PCAT version number
	  -e < all | net,perf,rsct,sec > 	To collect more details about selected areas 
                                        The argument "all" will collect all additional details 
                			The argument "net" will collect additional network related data
                                        The argument "rsct" will get data from all RMs known by RSCT
           				The argument "perf" will collect additional performance data
           				The argument "sec" will collect additional security data
	  -c <counter>		                The number of conters used for iostat, vmstat, and mpstat
	                                        Default=10 times 
	                                        Used for PowerView. Does activate the --pv flag
	  -d <output directory>		        To specify a different output directoy (default is .../pcat/)
	  -i <interval>		                The time interval (sec.) for iostat, vmstat, and mpstat
						Default = 60 sec.
  	                                        Used for PowerView. Does activate the --pv flag
	  --hmc < hmc-name | hmc-address>	To collect data from specified hmc. 
                                        It does not work with the option --nohmc. 
                                        The option --noos is automatticaly applied.
	  --fsm [ fsm-name | fsm-address ]	To collect data from specified FSM. 
                                        It does not work with the option --nohmc. 
	  --id <hmc-id|fsm-id>		        User id used to run the data collection on the HMC (default = hscroot)
	  --nmon < all | large | last | two >	To collect nmon data if started from inittab. 
	  --nohmc	 		        Do not attempt to collect HMC/FSM data
	  --nofsm				Do not attempt to collect FSM/HMC data
	  --nomds				Do not check for the catalog.mic file
	  --noos	 		        Do not attempt to collect OS data
	  --notsm		        	Do not prompt for TSM admin ID and password
	  --noinstallkey 		        Do not install an ssh key for the HMC
	  --noprompts			        Does suppress prompting for additional input
	  --pv | --PowerView			Does collect additional PowerView data (using Default values)
	  --site <site name>                    To specify the site name where the system is located
	  --snap				Does additionaly create a snap file and puts the PCAT data into the snap


	Further details can be found in the README.txt file
	!
  if
    [ ! -z "$QUERYTYPE" ]
  then
    extraflags=`assess_flags "$QUERYTYPE" | sed 's%^%    --%'`
    test ! -z "$extraflags" && cat <<-! >&2
	Other supported flags for the $QUERYTYPE assessment:
	$extraflags
	!
  fi
  exit 1

#	  --maketar	 		Create a tar ball of the tool package
}

#
#	Where should we find our rule files, etc?
#
compute_startdir() 
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi 
  DirName=""
  case $0 in
   /*)		startdir=`dirname "$0"`;;
   */*)		DirName=$(dirname "$0")
		DirNameLengs=$(echo ${DirName} | wc -m)
                if [ ${DirNameLengs} -le 2 ]
                then 
                  startdir="`pwd`"
                else
                  if ( echo ${DirName} | grep -q '\.' )
                  then
                    startdir="$(pwd)/$(echo ${DirName} | cut -c3-)"
                  else
                    startdir="`pwd`/${DirName}"
                  fi
                fi;; 
   *)		startdir=`pwd`;;
  esac
  echo "$startdir" | sed -e 's%^\./%%' -e's%/\./%/%'  -e 's%[^/][^/]*/\.\./%/%g'
}

check_sh_environment()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi 
# we check if there is a symbolic or hard link from "sh" to "bash" or "ksh"
# if not the system exit with an error
  Used_shell=$(ls -il /bin/sh)
  if [ $(echo $Used_shell | awk '{ print $3}') -eq 1 ]
  then
    echo $Used_shell | egrep "bash|ksh" > /dev/null 2>&1
    CheckSh=$?
    if [ $CheckSh -ne 0 ]
    then
      if [ "$(uname)" = "Darwin" ]
      then 
        CheckSh=0
      fi
    fi
  else
    CheckHardLinks=$(ls -il /bin/* | grep "$(echo $Used_shell | awk '{ print $1}')")
    echo $CheckHardLinks | egrep "bash|ksh" > /dev/null 2>&1
    CheckSh=$?
  fi
  if [ $CheckSh -ne 0 ]
  then
    out "#############################"
    out "###   Local environment   ###"
    out "###      E R R O R        ###"
    out "#############################"
    out "FATAL shell ERROR: Local System does not use a supported shell (bash or ksh)"
    out "General sh settings are \"$Used_shell\" "
    out ""
    out "Check if you can link sh to bash or ksh"
    out "Default shell for $LOGNAME is $SHELL"
    out ""
    exit 1
  fi
}


system_supports_hmcs() {
   if [ "$PCATDEBUG" = "on" ]; then set -x; fi  
  arch=`compute_architecture`
  case $arch in
    p)	true;;
    *)	false;;
  esac
}


compute_hmclist_linux() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  list=""
  j=0
  while
    [ $j -lt 16 ]
  do
    q=`$LINUX_HMC_QUERY -e hmc$j `
    case "$q" in
     	*'HmcStat=1;'*)
		ip=`out "$q" |  sed -e 's%.*HscIPaddr=%%i' -e 's%;.*%%i'`
		if
		  [ -z "$list" ]
		then
		  list="$ip"
		else
		  list="$list $ip"
		fi
		;;
    esac
    j=`expr $j + 1`
  done
  HMCLIST="$list"
  out "$HMCLIST"
}


compute_hmclist_aix() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if [ "`oslevel`" = "7.1.0.0" ]
  then
    HMCLIST=`$AIX7_HMC_QUERY | grep -iw IPAddresses | awk -F\" '{print $2}'`
  else
    HMCLIST=`$AIX_HMC_QUERY | grep '^	Hostname *= *"' | cut -d'"' -f2`
    if [ -z "$HMCLIST" ]
    then
      HMCLIST=`$AIX7_HMC_QUERY | grep -iw IPAddresses | awk -F\" '{print $2}'`
    fi
  fi
  HMCLIST=`out $HMCLIST`
  out $HMCLIST
}


has_hmcs() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if
    system_supports_hmcs
  then
    case $OSCLASS in
      aix)	compute_hmclist_aix > /dev/null;;
      *)	compute_hmclist_linux > /dev/null;;
    esac
    test ! -z "$HMCLIST"
  else
    out "System does not have HMCs"
    false
  fi
}


get_all_hmc_info() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  out ""
  if [ $FLAG_fsm -eq 0 ]
  then
    HMCLOG=$BASEDIR/${SystemDir}/$HOSTNAME/hmc.d/pcat-hmc.txt
    HMC_Counter=0
    mkdir -p `dirname $HMCLOG`
    (
      if [ -a /tmp/pcat.hmc.fail ]
      then
        rm /tmp/pcat.hmc.fail > /dev/null
      fi
      out "Beginning HMC data collection for $QUERYTYPE at `date`"
      for hmc in $HMCLIST
      do
        let HMC_Counter=${HMC_Counter}+1
        out "Getting information about HMC $hmc"
        export HMC_Counter
        $SH $BASEDIR/pcat-hmc.sh  "$1" "$hmc" 
        if [ $? -ne 0 ]
        then
	  touch /tmp/pcat.hmc.fail   
          false
	fi
      done 2>&1
      out "Ending $QUERYTYPE HMC data collection for $QUERYTYPE at `date`"
      out "Log from this HMC data collection session can be found in $HMCLOG"
    ) | tee -a $HMCLOG
    if [ -a /tmp/pcat.hmc.fail ]
    then
      rm /tmp/pcat.hmc.fail > /dev/null
      out "Error in executing \"$SH $BASEDIR/pcat-hmc.sh $1 $hmc \""
      usage
      exit 1
    fi
  else
    HMCLOG=$BASEDIR/${SystemDir}/$HOSTNAME/fsm.d/pcat-fsm.txt
    mkdir -p `dirname $HMCLOG`
    (
      if [ -a /tmp/pcat.hmc.fail ]
      then
        rm /tmp/pcat.hmc.fail > /dev/null
      fi
      out "Beginning FSM data collection for $QUERYTYPE at `date`"
      for hmc in $HMCLIST
      do
        out "Getting information about FSM $hmc"
        $SH $BASEDIR/pcat-fsm.sh  "$1" "$hmc"
        if [ $? -ne 0 ]
        then
          touch /tmp/pcat.hmc.fail
          false
	fi
      done 2>&1
      out "Ending $QUERYTYPE FSM data collection for $QUERYTYPE at `date`"
      out "Log from this FSM data collection session can be found in $HMCLOG"
    ) | tee -a $HMCLOG
    if [ -a /tmp/pcat.hmc.fail ]
    then
      rm /tmp/pcat.hmc.fail > /dev/null
      out "Error in executing \"$SH $BASEDIR/pcat-fsm.sh  $1 $hmc \""
      usage
      exit 1
    fi
  fi
}

add_temp_key_to() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  SSH_OPTIONS="-i $TMPKEYNAME"; export SSH_OPTIONS
#  tempauthhosts=/var/tmp/$$.authorized_keys
  out "Installing temporary ssh key in HMC $1"
  if
    [ ! -f "$TMPKEYNAME" ]
  then
    ssh-keygen -q -t rsa -b 2048 -N "" -f $TMPKEYNAME
  fi
  out "You will need to supply the password to $1 twice."
  tmpdir=/tmp/$$.$RANDOM.auth
  mkdir $tmpdir
  chmod 700 $tmpdir
  if
    scp -q $SSH_OPTIONS "$1:.ssh/${AUTHORIZED_KEYS}*" $tmpdir/
  then
    AUTHORIZED_KEYS=`ls $tmpdir | head -n 1`
    cat "$TMPPUBKEYNAME" >> $tmpdir/$AUTHORIZED_KEYS
    scp -q $SSH_OPTIONS $tmpdir/$AUTHORIZED_KEYS $1:.ssh/$AUTHORIZED_KEYS
  else
#    touch $tempauthhosts
    scp -q $SSH_OPTIONS $TMPPUBKEYNAME $1:.ssh/$AUTHORIZED_KEYS
  fi
  out "Temporary ssh key installed in HMC $1."
#  rm -f tempauthhosts
  rm -fr $tmpdir
  if [ "$OSCLASS" = "linux" ]
  then
    ssh-add $TMPKEYNAME
  fi
}

rm_temp_key_from() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  tempauthhosts=/var/tmp/$$.authorized_keys
  tempauthhosts2=/var/tmp/$$.authorized_keys-2
  if
    [ ! -f $TMPKEYNAME ]
  then
    out "Temporary ssh key [$TMPKEYNAME] not present in HMC $1."
    return
  fi
  scp -q $SSH_OPTIONS $1:.ssh/$AUTHORIZED_KEYS $tempauthhosts
  OURPUBKEY=`cat $TMPPUBKEYNAME`
  if
    grep  "$OURPUBKEY" $tempauthhosts >/dev/null
  then
    grep  -v "$OURPUBKEY" $tempauthhosts > $tempauthhosts2
    scp -q $SSH_OPTIONS $tempauthhosts2 $1:.ssh/$AUTHORIZED_KEYS
    out "Temporary ssh key removed from HMC $1."
  else
    out "Temporary key [$TMPKEYNAME] not present in destination."
  fi
  rm -f $TMPKEYNAME $TMPPUBKEYNAME $tempauthhosts $tempauthhosts2
}

install_temporary_hmc_keys() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  RC_SSH=$(lslpp -L "openssh.base.*" > /dev/null 2>&1; echo $?)
  if [[ $RC_SSH -eq 0 || $FLAG_Force_SSH -eq 0 ]]
#  if lslpp -L "openssh.base.*" > /dev/null 2>&1
  then
    for hmc in $HMCLIST
    do
      add_temp_key_to $HMCID@$hmc
    done
  else
    if  which ssh > /dev/null 2>&1 
    then
      echo "\n!! Warning !!  No OpenSSH installed!"
      echo "Other ssh product installed \n"
      echo "You need to setup a ssh key based authentication to your HMC from this system."
      echo "Then execute the pcat.sh script with the option --noinstallkey"
      echo "or"
      echo "If you are sure the commands we use will work within your ssh version !!"
      echo "you can execute the pcat.sh script with the option --force-ssh"
      exit 1
    else
      echo "\n!! ERROR !!  No ssh installed \n"
      exit 1
    fi
  fi
}
remove_temporary_hmc_keys() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  for hmc in $HMCLIST
  do
    rm_temp_key_from $HMCID@$hmc
  done
}


#
#	Make a tar file of all our output from this LPAR...
#
packageoutput() 
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  ActualDir=$(pwd)
  cd ${MainOutDir}
  cd ..
  if
    rm -f "${HOSTNAME}.tar.gz"
    tar cf "${HOSTNAME}".tar ${SystemDir}/${HOSTNAME} && gzip "${HOSTNAME}".tar
  then
    FILES=`gunzip - < $HOSTNAME.tar.gz | tar tf - | grep -c '\.txt$'`
    out "Output tar file $HOSTNAME.tar.gz created containing" $FILES "data files."
    ls -ld $HOSTNAME.tar.gz
  elif
    [ -f "$HOSTNAME.tar" ]
  then
    FILES=`tar tf $HOSTNAME.tar | grep -c '\.txt$'`
    out "Output tar file $HOSTNAME.tar created with containing" $FILES "data files."
    ls -ld $HOSTNAME.tar
  else
    out "OOPS! Failed to create Output tar file"
  fi
  if [ "$OSCLASS" = "aix" -a "$FLAG_snap" = "1" ]
  then
    echo "Start of snap -gGfkLN $(date)" >> $ExecutionLogFile
    # Clean up old snaps
    echo "y" | snap -r 
    # Collect new; don't package yet
    snap -gGfkLN
    cp $HOSTNAME.tar* /tmp/ibmsupt/other 
    # Package snap and other data
    snap -c 
  fi
  cd ${ActualDir}
}



MakeTarFile() {
  NAME=$(basename ${BASEDIR})
  cd ${BASEDIR}/..
  FILES=`ls $NAME/*-ext.sh $NAME/*-cmds.txt $NAME/*.pl $NAME/README* $NAME/ChangeLog* $NAME/*pcat*.sh`
  tar cf pcat-install-$VERSION.tar $FILES
}

##PROMPTFOR	FLAG_notsm	IsTSMLoaded	TSMADMID TSM Login name
##PROMPTFOR	FLAG_notsm	IsTSMLoaded	TSMADMPASS	TSM Login password
#
#	All the extra prompts we might have to issue are contained in the extension
#	files in prompts similar to the ones above.
#
interactive_prompts() {
  assess_type="$1"
  INC_FILES=`assessment_files "$assess_type" "ext.sh"`
  ourscript="/tmp/$$.$RANDOM.script"
  ourprompts="/tmp/$$.$RANDOM.prompts"
  if
    grep '^##PROMPTFOR' $INC_FILES < /dev/null >$ourprompts
  then
    : 'We have work to do.  Soldier on!'
  else
    return
  fi
  for file in $INC_FILES
  do
    . $file
  done
  out "#Start of $ourscript" > $ourscript
  chmod 600 $ourscript
  #
  #	We do this in kind of a weird way because I/O redirection
  #	of while loops typically creates a child process and efffectively
  #	keeps us from setting variables that can be used later.
  #
  while
    read dummy disableflagname funtocall varname prompt
  do
    if
      $funtocall && eval test  \$\{$disableflagname-0\}\ -eq 0
    then
      case $prompt in
         *pass*)	out "stty -echo 2>/dev/null"
      esac
      out printf \"Please enter %s: \" \"$prompt\" '>&2'
      out "read $varname; export $varname"
      case $prompt in
         *pass*)	out "stty echo 2>/dev/null"
      esac
    else
      out "$disableflagname=1"
      out "unset $varname"
    fi
  done   < $ourprompts >>$ourscript
  . $ourscript
  rm -f $ourscript
}

assess_flags() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  INC_FILES=`assessment_files "$1" "ext.sh"`
  grep '^##PROMPTFOR' $INC_FILES < /dev/null | cut -f2 | sed 's%^FLAG_%%' | sort -u
}

create_main_outdir()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  test  ! -d "${MainOutDir}" && mkdir -p "${MainOutDir}" && chmod 777 ${MainOutDir}
  #if [[ -d "${MainOutDir}" ]]
  #then
  #  out "Deleting old Systems Dir (${MainOutDir})" 
  #  rm -r ${MainOutDir}
  #fi
  #mkdir -p ${MainOutDir}
  #chmod 777 ${MainOutDir}
}

check4catalog_mic()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if [ -f ${BASEDIR}/catalog.mic ]
  then
    return
  else
    out "" 
    out "#################################"
    out "###       W A R N I N G       ###"
    out "###    No catalog.mic file    ###"
    out "###  in pcat directory found  ###"
    out "#################################"
    out ""
    out "using the option --nomds will skip this check"
    out ""
    out "Continue ? (yes/no)  [no] "
    read Answer
    Answer=$(echo $Answer | tr 'A-Z' 'a-z')
    if [[ "$Answer" = "yes" || "$Answer" = "y" || "$Answer" = "ye" ]] 
    then
      return
    else
      exit 1
    fi
  fi
}

getMDScatalog()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  # in development not used yet
  wget http://techsupport.services.ibm.com/server/mdownload/catalog.mic
  #curl -get http://techsupport.services.ibm.com/server/mdownload/catalog.mic > catalog.mic
  curl -get http://public.dhe.ibm.com/software/server/firmware/catalog.mic > catalog.mic
}

printversion()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  out "PCAT version: ${VERSION}"
  exit 0
}

##########################################################################
# Main
##########################################################################
#set -x
if [ "$PCATDEBUG" = "on" ]; then set -x; fi

umask 022
PCAT_Input="${0} ${@}"

BASEDIR=`compute_startdir`
. $BASEDIR/commonpcatdefs.sh

check_sh_environment

FLAG_extention=0
FLAG_rsct=0
FLAG_perf=0
FLAG_net=0
FLAG_sec=0
export FLAG_extention FLAG_rsct FLAG_perf FLAG_net FLAG_sec
FLAG_hmc_id=0
FLAG_nohmc=0
FLAG_hmc=0
FLAG_fsm=0
export FLAG_nmon=0
FLAG_noos=0
FLAG_noprompts=0
FLAG_noinstallkey=0
FLAG_noroot=0
FLAG_nomds=0
FLAG_snap=0
FLAG_Force_SSH=1
# FLAG_Force_SSH=1 means force option is not used 
# FLAG_Force_SSH=0 means that the system will not check which ssh is installed and the defied ssh commans will be used 
FLAG_PV=0
TMPKEYNAME=$HOME/.ssh/id_ibmlbspcat_tmp
TMPPUBKEYNAME=${TMPKEYNAME}.pub
FlagSiteName=""
MainOutDirIsNFS=0

HOSTNAME=`GetHostName`
MainOutDir=${BASEDIR}/${SystemDir}
export BASEDIR HOSTNAME MainOutDir FLAG_snap FlagSiteName FLAG_PV PCAT_Input

HMCLIST=""

QUERY_HMCS=1
QUERY_HOSTS=1

LINUX_HMC_QUERY="/usr/sbin/serv_config"
AIX_HMC_QUERY="lsrsrc -l IBM.ManagementServer"
AIX7_HMC_QUERY="lsrsrc -l IBM.MCP"

EXTRAFLAGS=""

while
  case "$1" in
    --debug)		export PCATDEBUG="on"; 	true;;
    -V)			printversion;;
    -c)			if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then 
			  out ""
			  out "ERROR: No arguments specified for option '-c'" >&2 
			  out ""
			  usage		
			  exit 1
			else
			  if [[ "${2%%*( )+([0-9])?(.)*([0-9])}" = "" ]]
			  then
			    StatCount=${2}
                            export StatCount
			    FLAG_PV=1
			    export FLAG_PV
			    shift
			  else
			    out ""
			    out "ERROR: Argument must be an integer for option '-c'" >&2 
			    out ""
   			    usage
			    exit 1
			  fi
			fi
			;;
    -d)			if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then
			  out ""
			  out "ERROR: No arguments specified for option '-d'" >&2 
			  out ""
			  usage		
			  exit 1
			else
			  if [[ "$(echo $2 | cut -c 1)" = "/" ]]
			  then
			    MainOutDir="${2}/${SystemDir}"
			    if [[ -d "${2}" ]]
			    then
			      if [[ -w ${2} ]]
			      then
			        : Dir ${2} has write permissions
			      else
			        out ""
			        out "ERROR: Directory ${2} has no Write permission " >&2 
			        out ""
			        usage		
			        exit 1
			      fi
			    else
			      mkdir -p ${2}
			      if [ $? -ne 0 ]
			      then
			        out ""
			        out "ERROR: Directory ${2} can not be creasted " >&2 
			        out ""
			        exit 2
			      else
			        chmod 777 ${2}
			      fi
			    fi
			  else
			    CurrDir=$(echo "$(pwd)" | sed -e 's%^\./%%' -e's%/\./%/%'  -e 's%[^/][^/]*/\.\./%/%g' )
			    TargetDir=${CurrDir}/${2}
			    if [[ -d "${TargetDir}" ]]
			    then
			      if [[ -w ${TargetDir} ]]
			      then
			        : Dir ${TargetDir} has write permissions
			        MainOutDir="${TargetDir}/${SystemDir}"
			      else
			        out ""
			        out "ERROR: Directory ${TargetDir} has no Write permission " >&2 
			        out ""
			        usage		
			        exit 1
			      fi
			    else
			      mkdir -p ${TargetDir}
			      if [ $? -ne 0 ]
			      then
			        out ""
			        out "ERROR: Directory ${TargetDir} can not be creasted " >&2 
			        out ""
			        exit 2
			      else
			        chmod 777 ${TargetDir}
			      fi
			    fi
			  fi
			fi
		        export MainOutDir
			shift
			;;
    -e)			if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then
			  out "";
			  out "ERROR: No arguments specified for option '-e'" >&2 ;
			  out "";
			  usage;		exit 1;
			else
			  if $(echo $2 | grep -q ",")
			  then
			    e_args=$(echo $2 | tr "," " ")
			  else
			    e_args=$2
			  fi
			  echo $e_args | tr " " "\n" | 
	                  while 
			    read -r args
			  do 
			    case "$args" in
			      all)	FLAG_extention=1;
					FLAG_rsct=1;
					FLAG_perf=1;
					FLAG_net=1;
					FLAG_sec=1;
					true ;;
			      rsct)	FLAG_extention=1;
					FLAG_rsct=1;
					true ;;
			      perf)	FLAG_extention=1;
					FLAG_perf=1;
					true ;;
			      net)	FLAG_extention=1;
					FLAG_net=1;
					true ;;
			      sec)	FLAG_extention=1;
					FLAG_sec=1;
					true ;;
			      *)	out "";
					out "ERROR: Wrong argument(s) specified for option '-e'" >&2 ;
			  		out "";
					usage;			exit 1 ;;
			    esac 
			  done 
			fi 
			export FLAG_extention FLAG_rsct FLAG_perf FLAG_net FLAG_sec
			shift
			true ;;
    -i)			if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then 
			  out ""
			  out "ERROR: No arguments specified for option '-i'" >&2 
			  out ""
			  usage		
			  exit 1
			else
			 if [[ "${2%%*( )+([0-9])?(.)*([0-9])}" = "" ]]
			 then
		 	    StatSec=${2}
			    export StatSec
			    FLAG_PV=1
			    export FLAG_PV
                            shift
			  else
			    out ""
			    out "ERROR: Argument must be an integer for option '-i'" >&2 
			    out ""
   			    usage
			    exit 1
			  fi
			fi
			;;
    --force-ssh)	FLAG_Force_SSH=0;	true;;
    --id)		if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then
			  out "";
			  out "ERROR: No HMC-Userid specified for option '--id'" >&2 ;
			  out "";
			  usage;		exit 1;
			else
			  FLAG_hmc_id=1;
			  HMCID=$2; shift; 	true;
			fi ;
			export HMCID;		true ;;
    --maketar)		MakeTarFile;		exit 0;;
    --mds)		if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then
			  out "";
			  out "ERROR: No arguments specified for option '--mds'" >&2 ;
			  out "";
			  usage;		exit 1;
                        else
			  case "$2" in
			      get)	FLAG_mds=0;
					true ;;
			      ignore)	FLAG_mds=1;
 					FLAG_nomds=1;
					true ;;
			      i)	FLAG_mds=1;
 					FLAG_nomds=1;
					true ;;
                              *)	out "";
					out "ERROR: Wrong argument(s) specified for option '-mds'" >&2 ;
			  		out "";
					usage;			exit 1 ;;
			  esac 
                        fi;;
    --nohmc)		FLAG_nohmc=1;		true;;
    --nofsm)		FLAG_nohmc=1;		true;;
    --nomds)		FLAG_nomds=1;		true;;
    --noos)		FLAG_noos=1; 
			FLAG_nomds=1;		true;;
    --hmc)		for i in $@ 
 			do 
			  if [[ "$i" = "--nohmc" || "$i" = "--nofsm" || $FLAG_nohmc -eq 1 ]]
			  then
			    out ""
			    out "ERROR: Option \"$i\" can not be used in combination with option '--hmc'" >&2 
			    out ""
			    usage;		exit 1;
			  fi 
			done
			if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then
			  out "";
			  out "ERROR: No \"HMC-Name\" or \"HMC-Address\" specified for option '--hmc'" >&2 ;
			  out "";
			  usage;		exit 1;
			else
			  HMCLIST_manual=$2; shift; 	true;
			fi ;
			FLAG_hmc=1; FLAG_noos=1; FLAG_nomds=1; true ;;
    --fsm)		for i in $@ ;  
 			do 
			  if [[ "$i" = "--nohmc" || "$i" = "--nofsm" || $FLAG_nohmc -eq 1 ]]
			  then
			    out "";
			    out "ERROR: Option \"$i\" can not be used in combination with option '--fsm'" >&2 ;
			    out "";
			    usage;		exit 1;
			  fi ;
			done
			if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then
			  out ""
			  out "Warning: No \"FSM-Name\" or \"FSM-Address\" specified"
			  out "trying to find a system defined FSM"	
			#  out "ERROR: No \"FSM-Name\" or \"FSM-Address\" specified for option '--fsm'" >&2 ;
			  out ""
			 # usage;		exit 1;
			else
			  HMCLIST_manual=$2; shift; 	true
			fi 
			FLAG_hmc=1; FLAG_fsm=1; FLAG_nomds=1; true ;;
    --noprompts)	FLAG_noprompts=1;	true;;
    --nmon)		if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then
			  out "";
			  out "ERROR: No argument specified for option '--nmon'" >&2 ;
			  out "";
			  usage;		exit 1;
			else
			  if [[ "$2" = "all" || "$2" = "two" || "$2" = "large" || "$2" = "last" ]]
			  then 
			    export FLAG_nmon=1;
			    export NMON_args=$2; shift; true;
			  else
			    out "";
			    out "ERROR: Wrong argument used for option '--nmon'" >&2 ;
			    out "";
			    usage;		exit 1;
			  fi ;
			fi			;;
    --noinstallkey)	FLAG_noinstallkey=1;	unset SSH_OPTIONS; true;;
    --pv|powerview|PowerView)	
			FLAG_PV=1 
			export FLAG_PV
			;;
    --site)		if [[ "$2" = "" || "$(echo $2 | cut -c 1)" = "-" ]]
			then
			  out ""
			  out "ERROR: No arguments specified for option '--site'" >&2 
			  out ""
			  usage;		exit 1
                        else
			  FlagSiteName="${2}"
			  export FlagSiteName
			fi
			shift
			;;
    --snap)		FLAG_snap=1; 	true;;
    --*)		EXTRAFLAGS="$EXTRAFLAGS $1";;
    -h|--help|'?'|-'?')	usage;			exit 0;;
    -*)			usage;			exit 1;;
    *)			false;;
  esac
do
  shift
  if [ "$PCATDEBUG" = "on" ]; then out $1 ; fi
done

case $# in
  0)	QUERYTYPE="aa"
	FLAG_noroot=0
	;;
  1)	QUERYTYPE="$(echo $1 | tr 'A-Z' 'a-z')"
	if [ "${QUERYTYPE}" = "nr" ] 
        then 
	  FLAG_noroot=1
	fi
	;;
  *)	usage; exit 1
	;;
esac
export FLAG_noroot

ASSESSFLAGS=`assess_flags "$QUERYTYPE"`
for eflag in $EXTRAFLAGS
do
  found=0;
  for aflag in $ASSESSFLAGS
  do
    case $eflag in
      --$aflag)	found=1; break;;
    esac
  done
  if
    [ $found -eq 0 ]
  then
    out ""
    out "ERROR: $eflag not a legal flag for $0" >&2
    out "";
    usage
    exit 1
  fi
  eval FLAG_$aflag=1
done

if [ $FLAG_hmc_id -eq 0 ]
then
  export HMCID=$HMC_UserID
fi

create_main_outdir

if [[ -n $(df ${MainOutDir} | grep -v "^/dev"|tail +2) ]]
then
  MainOutDirIsNFS=1
fi 

US=`basename "$0"`
OSCLASS=`compute_osclass`
if [ "$OSCLASS" = "aix" ]
then
  if [ $FLAG_nomds -eq 0 ]
  then
    check4catalog_mic
  fi
fi

if
  [ $FLAG_noos -eq 0 -a $FLAG_noprompts -eq 0 ]
then
  interactive_prompts "$QUERYTYPE"
fi

if [ $FLAG_hmc -eq 0 ]
then 
  #HMCOUTDIR=${MainOutDir}/$HOSTNAME/hmc.d
  #test -d "$HMCOUTDIR" || mkdir -p "$HMCOUTDIR"
  #HMCLOG=${HMCOUTDIR}/pcat-hmc.txt
  if
    [ $FLAG_nohmc -eq 0 ] && has_hmcs
  then
    HMCOUTDIR=${MainOutDir}/$HOSTNAME/hmc.d
    test -d "$HMCOUTDIR" || mkdir -p "$HMCOUTDIR"
    HMCLOG=${HMCOUTDIR}/pcat-hmc.txt
    out "PCAT tool started using: ${PCAT_Input}" | tee ${HMCLOG}
    out "$(date +"%Y/%m/%d %H:%M:%S")" | tee -a ${HMCLOG}  
    if [ ${MainOutDirIsNFS} -eq 1 ]
    then
      out "Output directory is on NFS" | tee -a ${HMCLOG}
    fi
    out "$US: HMC data acquisition phase." | tee -a ${HMCLOG}
    out "The current host (`uname -n`) knows about the following HMCs: $HMCLIST" | tee -a ${HMCLOG}
    if
      [ $FLAG_noinstallkey -eq 0 ]
    then
      install_temporary_hmc_keys
    fi
    get_all_hmc_info "$QUERYTYPE"
    if [ $? -ne 0 ]
    then
      false
    fi
    if
      [ $FLAG_noinstallkey -eq 0 ]
    then
      remove_temporary_hmc_keys
    fi
    out ""
  fi
else
  HMCOUTDIR=${MainOutDir}/$HOSTNAME/hmc.d
  test -d "$HMCOUTDIR" || mkdir -p "$HMCOUTDIR"
  HMCLOG=${HMCOUTDIR}/pcat-hmc.txt
  out "PCAT tool started using: ${PCAT_Input}" | tee ${HMCLOG}
  out "$(date +"%Y/%m/%d %H:%M:%S")" | tee -a ${HMCLOG}
  if [ ${MainOutDirIsNFS} -eq 1 ]
  then
    out "Output directory is on NFS" | tee -a ${HMCLOG}
  fi
  out "$US: manual HMC data acquisition phase." | tee -a ${HMCLOG}
  out "The current host (`uname -n`) collects data from the following HMC: $HMCLIST_manual" | tee -a ${HMCLOG}
  HMCLIST=$HMCLIST_manual
  if
    [ $FLAG_noinstallkey -eq 0 ]
  then
    install_temporary_hmc_keys
  fi
  get_all_hmc_info "$QUERYTYPE"
  if [ $? -ne 0 ]
  then
    false
  fi
  if
    [ $FLAG_noinstallkey -eq 0 ]
  then
    remove_temporary_hmc_keys
  fi
  out ""
fi
if
  [ $FLAG_noos -eq 0 ]
then
  test -d ${MainOutDir}/${HOSTNAME} || mkdir -p ${MainOutDir}/${HOSTNAME}
  OSOUTFILE="${MainOutDir}/${HOSTNAME}/pcat-os_sh-out.txt"
  test -a ${OSOUTFILE} || touch ${OSOUTFILE}
  out "$US: `uname -n` $OSCLASS data acquisition phase." | tee ${OSOUTFILE}
  out "$(date +"%Y/%m/%d %H:%M:%S")" | tee -a ${OSOUTFILE}
  if [ ${MainOutDirIsNFS} -eq 1 ]
  then
    out "Output directory is on NFS" | tee -a ${OSOUTFILE}
  fi
  $BASEDIR/pcat-os.sh "$QUERYTYPE" 
fi
out "$0: Packaging up data."
packageoutput
