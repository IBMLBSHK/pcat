#######################################################################
#
# Copyright(c) 2010 - 2018 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Author:      Alan Robertson, Bernhard Buehler
# Co-Author:		
# Support:              
#
#######################################################################
#
#	Functions available on Linux availability assessments (aa)
#
#######################################################################
if [ "$PCATDEBUG" = "on" ]; then set -x; fi

List_ET_bonding()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if [ -a /proc/net/bonding ]
  then
    NumberBonds=$(ls bond* 2> /dev/null | wc -w)
    if [ ${NumberBonds} -eq 0 ]
    then
      out "No Ethercannel bonds found"
      out "Directory /proc/net/bonding does not contain any bond device"
    else
      for i in $(ls -d /proc/net/bonding/bond*)
      do
        out "File $i"
        out "-----------------------------------------------------------"
        fileprint $i
        out ""
      done
    fi
  else
    out "No Ethercannel bonds defined"
    out "Directory /proc/net/bonding does not exist!"
  fi
}
LocalFS() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  while
    read dev mountpoint type options word1 word2
  do
    case $dev in
      none)		case $type in
			  tmpfs)	echo $mountpoint;;
			esac;;
      *:/*)		;;

      */*)		case $type in
			  nfs*|cifs|smbfs|rootfs)	;;
			  *)		echo $mountpoint;;
			esac;;
    esac
  done </proc/mounts | sort
}

NetFS() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  while
    read dev mountpoint type options word1 word2
  do
    case $dev in
      *:/*)		echo $mountpoint;;

      *)		case $type in
			  nfs*|cifs|smbfs)	echo $mountpoint;;
			esac;;
    esac
  done </proc/mounts | sort
}
#mount | grep -Fw "`LocalFS`"
#mount | grep -Fw "`NetFS`"
