#######################################################################
#
# Copyright(c) 2010 - 2018 International Business Machines (IBM) 
# This file created for use by the STG Lab Services organization
#
# Original Author:      Alan Robertson, Bernhard Buehler
# Co-Author:		
# Support:              
#
#######################################################################
#
#       Functions and definitions made available for availability
#	assessments on AIX
#
#######################################################################
if [ "$PCATDEBUG" = "on" ]; then set -x; fi  
#
# PATH information for HACMP
#
PATH=$PATH:/usr/es/sbin/cluster/utilities
PATH=$PATH:/usr/es/sbin/cluster/sbin
#
# PATH information for RSCT 
#
PATH=$PATH:/usr/sbin/rsct/bin
#
# PATH information for CAA 
#
PATH=$PATH:/usr/lib/cluster/
#
# PATH information for HDC (Hitachi) storage driver
#
PATH=$PATH:/usr/DynamicLinkManager/bin
export PATH
DirInvScout="/var/adm/invscout"

#
#	substitute for common mktemp code
#
mktemp() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  Name="/tmp/XXX-$$-$RANDOM.tmp"
  touch $Name
  echo $Name
}

VIOCLI=/usr/ios/cli/ioscli
export VIOCLI

CurrentOS=`oslevel`
export CurrentOS

run() {
   echo ""
   echo "Using comand: $@"
   eval "$@"
   echo ""
   echo "================================================================="
}


#if_gpfs() {
#	if
#	  lslpp -L 'gpfs.*' >/dev/null 2>&1
#	then
#	  true
#	else
#	  echo "GPFS not installed."
#	  false
#	fi
#}

list_active_vgs() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  echo "List content of active VGs"
  for i in `lspv | grep active | sort +2 -u | awk  '{print $3}'`
  do
    echo "VG: $i"
    echo ""
    run lsvg $i
    run lsvg -l $i
    run lsvg -p $i
    if
       [ "$OS" = "5.3.0.0" -o "$OS" = "5.2.0.0" -o "$OS" = "5.1.0.0" ]
    then
      echo "Skipping AIX 6 syntax"
    else
      run lsvg -m $i
      run lsvg -P $i
    fi
    echo "-----------------------------------------------------------------"
  done
}

list_concurrent_vgs() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  echo "List content of concurrent VGs"
  for i in `lspv | grep concurrent | sort +2 -u | awk  '{print $3}'`
  do
    echo "VG: $i"
    run lsvg $i
    run lsvg -l $i
    run lsvg -p $i
    if
       [ "$OS" = "5.3.0.0" -o "$OS" = "5.2.0.0" -o "$OS" = "5.1.0.0" ]
    then
      echo "Skiping AIX 6 syntax"
    else
      run lsvg -m $i
      run lsvg -P $i
    fi
    echo "-----------------------------------------------------------------"
  done
}

list_varyoff_vgs() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  echo "Check for Varied off vg\'s"
  for i in `lspv | grep -v active | grep -v concurrent | grep hdisk | grep -v None | sort +2 -u | awk  '{print $1}'`
  do
    run lsvg -n $i
  done
  echo ""
}

get_HA_rsct_details(){
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if [ $(halevel | cut -c 1) -ge 7 ]; then lsrsrc $@ ; fi
}

viorunsilent() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  tmp=/tmp/$$.silent
  trap "rm -f $tmp" 0
  if
    "$@" >$tmp 2>&1
  then
    echo RUNNING "$@"
    cat $tmp
    true
  else
    false
  fi
}

#	Not yet used...
viofieldnames() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  case $1 in
    vg)	
	cat <--!EOF
		vgname
		vgstate
		access
		vgid
		freepps
		usedpps
		auton
		hotspare
		autosync
		!EOF
	;;
    pv)
	cat <--!EOF
		pvname
		vgname
		pvid
		vgid
		pvstate
		ppsize
		hotspare
		!EOF
	;;
    lv)
	cat <--!EOF
		lvname
		vgname
		lvid
		vgstate
		lvstate
		type
		mount
		label
		!EOF
	;;
    vdisk)
	cat <--!EOF
		svsa
		physloc
		clientid
		vtd
		lun
		backing
		status
		!EOF
	;;
  esac
}

pr_vdiskmapinfo() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  vdiskfields="svsa physloc clientid vtd lun backing status"
  echo "#	Virtual Disk Mappings"
  echo "#VDMAP $vdiskfields" | tr ' ' ':'
  for adapter in `$VIOCLI lsmap -all -field svsa -fmt ':'`
  do
    echo "VDMAP:"`$VIOCLI lsmap -vadapter "$adapter" -fmt : -field $vdiskfields `
  done
}

vio_docit () {
# Docit Virtual Disk
# Lists disk mapping in condeNced form
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  echo " "
  echo "Hostname   Vhost  Vhost Connection         VTarget Name    IOS LUN        Phy Device"
  echo "------------------------------------------------------------------------------------------------"
  VIOS=$HOSTNAME
  for VHOST in `lsdev -Cc adapter|grep vhost |awk '{print $1}'`
  do
    VHOST_CONN=`lscfg -vl $VHOST |head -1 | awk '{print $2}'`
    for VTD in `lsdev -C -p $VHOST |awk '{print $1}'`
    do
      LUN=`lsattr -El $VTD -a LogicalUnitAddr | awk '{print $2}'`
      DEV=`lsattr -El $VTD -a aix_tdev | awk '{print $2}'`
      printf "$VIOS $VHOST $VHOST_CONN $VTD $LUN $DEV \n"
    done
  done
}


vio_virt_phys_map() {
#
#	Print virtual->physical mappings, organized by device type
#
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  for dtype in optical file file_disk file_opt disk lv net
  do
    echo "Virtual $dtype device mappings"
    $VIOCLI lsmap -all -type $dtype
    echo ""
  done
}

#
#	The manual mentions tape, but I've not seen it implemented yet...
#
#
#	Print mapping about logical volumes that are mapped to
#	virtual devices.
#

vio_volume_mapping() {
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  echo "Logical Volume Mappings"
  lsmapout=`$VIOCLI lsmap -all -type lv -fmt : -field svsa vtd backing `
  sIFS="$IFS"
  IFS=":$IFS"

  cat <<-!
#LV:backing:vtd:svsa
#  VG:vgname
#    PV:pvname:pvid
!

  echo "$lsmapout" | \
  while
    read svsa vtd backing
  do
    lv="$backing"
    echo "LV:$backing:$vtd:$svsa"
    for vg in `$VIOCLI lslv $lv -field vgname -fmt :`
    do
      echo "  VG:$vg"
      for pv in `$VIOCLI lsvg -pv $vg -field pvname -fmt :`
      do
        echo "    PV:"`$VIOCLI lspv $pv -fmt : -field pvname pvid`
      done
    done
    echo ""
  done
  IFS=$sIFS
}

get_nmon4pv()
{
  if [ ${StatSec} -ge 60 ]
  then
    nmon -ft -s ${StatSec} -c ${StatCount} -m "${MainOutDir}/${HOSTNAME}/powerv" -AOPVdMT
    NmonCount=${StatCount}
  else
    let CollectTime=${StatSec}*${StatCount}
    if [ ${CollectTime} -ge 60 ]
    then
      let MinStatCount=$(${CollectTime}/60)+2
      nmon -ft -s 60 -c ${MinStatCount} -m "${MainOutDir}/${HOSTNAME}/powerv" -AOPVdMT
      NmonCount=${MinStatCount}
    else
      nmon -ft -s 60 -c 3 -m "${MainOutDir}/${HOSTNAME}/powerv" -AOPVdMT
      NmonCount="3"
    fi
  fi
  out "NmonCount=${NmonCount}" > ${MainOutDir}/${HOSTNAME}/powerv/pcat_values.txt
  out "nmon files are located under ${MainOutDir}/${HOSTNAME}/powerv "
}

#
# convert topas data to nmon and copy it to the data collection
# handled by subrutines get_nmon_data, get_nmon_files and get_topas_dir
#
get_topas_dir()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  CheckInput=true
  while $CheckInput
  do
    if [ -z $1 ]
    then
      CheckInput=false
      TopasDir=""
    elif [ "$1" = "-o" ]
    then
      shift
      TopasDir=$1
      CheckInput=false
    else
      shift
    fi
  done
}

get_nmon_files()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  for i in $NMON_files
  do
    j=$(basename $i .topas) 
    topasout -a $i 
    mv $i.csv $j.nmon 
    echo "copying $j.nmon to .../Systems/${HOSTNAME}/perf/nmon.d/" 
    cp $j.nmon ${MainOutDir}/${HOSTNAME}/perf/nmon.d/ 
    rm $j.nmon
  done 
}

get_nmon_data()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  CurrentDir=$BASEDIR
#  TopasDir=$(lsitab xmdaily| tr " " "\n" | grep -w daily)
  TopasDev=$(lsitab xmdaily)

  if [ $FLAG_nmon -eq 0 ]
  then 
    echo "nmon flag not used. "
    echo "Therefore data collection skiped"
  else
    echo "Used argument for nmon data colletion: $NMON_args"
    echo "---------------------------------------------------"
    if [ -z $TopasDev ]
    then
      echo "No Topas data collection started from inittab"
      echo "No xmdaily entry in /etc/inittab"
    else
      get_topas_dir $TopasDev
      if [ -z $TopasDir ]
      then
        # we should never be here !!
        echo "Error in geting Topas directory"
        echo "collected input was:"
        echo "$TopasDev"
      else
        mkdir -p ${MainOutDir}/${HOSTNAME}/perf/nmon.d 
        echo "Topas data are located in \"$TopasDir\" " 
        cd $TopasDir 
        # check for file names
        Files=$(ls $(hostname)*.topas)
        if [ $? -eq 0 ]
        then
          HostnameCMD="hostname"
        else
          Files=$(ls $(hostname -s)*.topas)
          if [ $? -eq 0 ]
          then
            HostnameCMD="hostname -s"
          else
            HostnameCMD=""
          fi
        fi
        if [ -z ${HostnameCMD} ]
        then
          out " No topas files for $(hostname) and/or $(hostname -s)"
        else
          case $NMON_args in
            all)	NMON_files=$(ls $(${HostnameCMD})*.topas) ;;
            large)	NMON_files=$(ls -S $(${HostnameCMD})*.topas | head -1) ;;
            last)	let t=$(date +"%y%m%d")-1 ; NMON_files=$(ls -S $(${HostnameCMD})_${t}.topas) ;;
	    two)	let t=$(date +"%y%m%d")-1 ; 
			NMON_files="$(ls -S $(${HostnameCMD})*.topas | head -1)"; NMON_files=$NMON_files" "$(ls $(${HostnameCMD})_${t}.topas) ;;
          esac
          get_nmon_files
        fi
        cd ${CurrentDir}
      fi
    fi
  fi  
}

#
# tries to run and collect the invscout data
# does only work if the catalog.mic is available in the pcat directory
#
get_invscout()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  if [ -s "${BASEDIR}/catalog.mic" ]
  then
    out "$(date +"%Y/%m/%d %H:%M:%S"):Copy ${BASEDIR}/catalog.mic to /var/adm/invscout/microcode/catalog.mic"
    cp ${BASEDIR}/catalog.mic /var/adm/invscout/microcode/catalog.mic
    out "$(date +"%Y/%m/%d %H:%M:%S"): Start invscout"
    /usr/sbin/invscout
    out "$(date +"%Y/%m/%d %H:%M:%S"): Program invscout finished"
    ls -l /var/adm/invscout/$(hostname -s).mup 2>&1
    cp "${DirInvScout}/$(hostname -s).mup" "${MainOutDir}/${HOSTNAME}/hw"
    out ""
    out "-----------------------------------------------------------------"
    out ""
    out "File \"${DirInvScout}/$(hostname -s).mup\" copied to \"${MainOutDir}/${HOSTNAME}/hw\""
  else
     out "No catalog.mic file found in ${BASEDIR}"
     out "invscout skiped"
  fi
}

#collect_aixpert_data()
#{
#}

# this is to collect the used PowerHA start and stop scripts
collect_PowerHA_scripts()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  CurrentDir=$BASEDIR
  StartStop=$(cldisp | egrep "started|stopped" | tr '\n' '^')
  OutPath="${MainOutDir}/${HOSTNAME}/ha"
  for hadir in $(echo $StartStop | tr '^' '\n' | awk '{print $1}' | sort -u)
  do
    echo "Creating output directory ${OutPath}/$hadir.d"
    mkdir -p ${OutPath}/$hadir.d
  done
  echo ""
  echo "Start collecting Start and Stop scripts for defined resource groups"
  echo "$StartStop" | tr '^' '\n' | awk '{print $1 " " $5}' |
  while
    read hadir ScriptName
  do
    if [[ -z $hadir || -z $ScriptName ]]
    then
      return
    else
      echo "$(ls -eli ${ScriptName})"
      CMD="fileprint ${ScriptName}"
      OutFile="${OutPath}/${hadir}.d/$(cmdtoname "${CMD}")"

     (
      cat > "$OutFile" 2>&1 <<-!EndCatHA
	==== This output can be found in $outfile ====
	==== START $CMD `date` ====
	!EndCatHA
      eval "( $CMD 
          )"  >>  "$OutFile" 2>&1 </dev/null
      rc=$?
      cat >> "$OutFile" 2>&1 <<-!EndCatHA2
	==== EXITED with rc $rc ====
	==== END $CMD `date` ====
	!EndCatHA2
     ) </dev/null

    fi
  done
  echo "Data collection finished based on:"
  echo "$StartStop" | tr '^' '\n' |
  while
    read InputString
  do
    echo $InputString
  done
}

# this is to collect the used PowerHA Custom scripts if there are some defined
collect_Custom_scripts()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi
  CurrentDir=$BASEDIR
  DevinedCustom=$(cllscustom)
  if [ -z "$DevinedCustom" ]
  then 
    out "No Custom scripts defined"
  else
    OutPath="${MainOutDir}/${HOSTNAME}/ha/custom.d"
    out "Creating output directory ${OutPath}"
    mkdir -p ${OutPath}
    CustomScripts=$(cllscustom -c | tail -n +2 | awk -F ":" '{print $1 ":" $4}')
    out ""
    out "Start collecting defined Custom scripts"
    echo "${CustomScripts}" | tr ':' ' ' | 
    while
      read CustomName ScriptName
    do
      out "${CustomName}:	$(ls -eli ${ScriptName})"
      CMD="fileprint ${ScriptName}"
      OutFile="${OutPath}/${CustomName}_$(cmdtoname "${CMD}")"

     (
      cat > "$OutFile" 2>&1 <<-!EndCatHA
	==== This output can be found in $OutFile ====
	==== START $CMD `date` ====
	!EndCatHA
      eval "( $CMD 
          )"  >>  "$OutFile" 2>&1 </dev/null
      rc=$?
      cat >> "$OutFile" 2>&1 <<-!EndCatHA2
	==== EXITED with rc $rc ====
	==== END $CMD `date` ====
	!EndCatHA2
     ) </dev/null

    done
    out "Data collection finished based on:"
    out "$CustomScripts" 
  fi
}

get_HA_event_Modification()
{
  if [ "$PCATDEBUG" = "on" ]; then set -x; fi 
  FileName="/tmp/XXX-HA-$$-$RANDOM.tmp"
  touch $FileName
  odmget -q 'notify!=""' HACMPevent | awk ' $1 == "name" { gsub("\"","") ; print $3}' >> $FileName
  odmget -q 'pre!=""' HACMPevent | awk ' $1 == "name" { gsub("\"","") ; print $3}' >> $FileName
  odmget -q 'post!=""' HACMPevent | awk ' $1 == "name" { gsub("\"","") ; print $3}' >> $FileName
  odmget -q 'recv!=""' HACMPevent | awk ' $1 == "name" { gsub("\"","") ; print $3}' >> $FileName
  odmget -q 'event_duration!=0' HACMPevent | awk ' $1 == "name" { gsub("\"","") ; print $3}' >> $FileName
  if [ -s $FileName ]
  then
    OutPath="${MainOutDir}/${HOSTNAME}/ha"
    out "Event modification found for:"
    out "$(cat $FileName | sort -u )"
    out "------------------------------------------------------"
    OutFile="${OutPath}/odmget_HACMPevent_changes.txt"
    out "Details listed under ${OutFile}"
    CMDtext="odmget -q name=\<name\> HACMPevent"
    (
      cat > "$OutFile" 2>&1 <<-!EndCatHAE
	==== This output can be found in $OutFile ====
	==== START $CMDtext `date` ====
	!EndCatHAE
    ) </dev/null
    echo "$(cat $FileName | sort -u )" | 
    while
      read CMDevent
    do
      CMD="odmget -q name=${CMDevent} HACMPevent"
      OutFile="${OutPath}/odmget_HACMPevent_changes.txt"
      (
        eval "( $CMD 
          )"  >>  "$OutFile" 2>&1 </dev/null
        rc=$?
      )
    done
    (
      cat >> "$OutFile" 2>&1 <<-!EndCatHAE2
	==== EXITED with rc $rc ====
	==== END $CMD `date` ====
	!EndCatHAE2
     ) </dev/null

# Collect the notify scripts    
    NotifyEvents="$(odmget -q 'notify!=""' HACMPevent | awk ' $1 == "name" { gsub("\"","") ; print $3}')"
    if [ -n "${NotifyEvents}" ]
    then
      out ""
      out "Collecting Notification scripts"
      OutPath="${MainOutDir}/${HOSTNAME}/ha/notify.d"
      out "Creating output directory ${OutPath}"
      mkdir -p ${OutPath}
      out ""
      out "Start collecting defined Notify scripts"
      echo "${NotifyEvents}" | 
      while
        read EventName
      do
        NotifyScript=$(odmget -q name=${EventName} HACMPevent | awk ' $1 == "notify" { gsub("\"","") ; print $3}')
        out "Event: ${EventName}	NotifyScript: ${NotifyScript}"
        CMD="fileprint ${NotifyScript}"
        OutFile="${OutPath}/$(cmdtoname "${CMD}")"

        (
         cat > "$OutFile" 2>&1 <<-!EndCatHAN
       		==== This output can be found in $OutFile ====
		==== START $CMD `date` ====
		!EndCatHAN
         eval "( $CMD 
          	 )"  >>  "$OutFile" 2>&1 </dev/null
      	rc=$?
      	 cat >> "$OutFile" 2>&1 <<-!EndCatHAN2
		==== EXITED with rc $rc ====
		==== END $CMD `date` ====
		!EndCatHAN2
        ) </dev/null
        
      done
    else
      out "No Notification scripts defined"
    fi 

# Collect the recovery scripts
    RecoveryEvents="$(odmget -q 'recv!=""' HACMPevent | awk ' $1 == "name" { gsub("\"","") ; print $3}')"
    if [ -n "${RecoveryEvents}" ]
    then
      out ""
      out "Collecting Recovery scripts"
      OutPath="${MainOutDir}/${HOSTNAME}/ha/recov.d"
      out "Creating output directory ${OutPath}"
      mkdir -p ${OutPath}
      out ""
      out "Start collecting defined Recovery scripts"
      echo "${RecoveryEvents}" | 
      while
        read EventName
      do
        RecoveryScript=$(odmget -q name=${EventName} HACMPevent | awk ' $1 == "recv" { gsub("\"","") ; print $3}')
        out "Event: ${EventName}	RecoveryScript: ${RecoveryScript}"
        CMD="fileprint ${RecoveryScript}"
        OutFile="${OutPath}/$(cmdtoname "${CMD}")"

        (
         cat > "$OutFile" 2>&1 <<-!EndCatHAR
       		==== This output can be found in $OutFile ====
		==== START $CMD `date` ====
		!EndCatHAR
         eval "( $CMD 
          	 )"  >>  "$OutFile" 2>&1 </dev/null
      	rc=$?
      	 cat >> "$OutFile" 2>&1 <<-!EndCatHAR2
		==== EXITED with rc $rc ====
		==== END $CMD `date` ====
		!EndCatHAR2
        ) </dev/null
        
      done
    else
      out "No Recovery scripts defined"
    fi
  else
    out "No event modification found"  
  fi
  rm -f $FileName > /dev/null
}

lsattr_disk()
{
  Opt=$1
  Arg=$2
  NumArgs=$#
  #shift; shift
  # check if EMC powerpath is installed
  lslpp -L EMCpower.base > /dev/null 2>&1
  RC_EMCpower=$?
  if [ $RC_EMCpower -eq 0 ]
  then
    if [ ${NumArgs} -eq 0 ]
    then
      for i in $(lsdev -Ccdisk | grep hdiskpower | awk '{print $1}' )
      do
        echo "#### DISK: $i ####"
        lsattr -El $i
        echo ""
      done
    else
      for i in $(lsdev -Ccdisk | grep hdiskpower | awk '{print $1}' )
      do
        echo "#### DISK: $i ####"
        lsattr -El $i ${Opt} ${Arg}
        echo ""
      done
    fi
  else
    if [ ${NumArgs} -eq 0 ]
    then
      for i in $(lsdev -Ccdisk | awk '{print $1}' )
      do
        echo "#### DISK: $i ####"
        lsattr -El $i
        echo ""
      done
    else
      for i in $(lsdev -Ccdisk | awk '{print $1}' )
      do
        echo "#### DISK: $i ####"
        lsattr -El $i ${Opt} ${Arg}
        echo ""
      done
    fi
  fi
}

lscfg_disk()
{
  # check if EMC powerpath is installed
  lslpp -L EMCpower.base > /dev/null 2>&1
  RC_EMCpower=$?
  if [ $RC_EMCpower -eq 0 ]
  then
    echo "Using: lsdev -Ccdisk | grep hdiskpower | awk '{print \"\";system(\"lscfg -vl \" $1)}' "
    echo "-----------------------"
    echo ""
    lsdev -Ccdisk | grep hdiskpower | awk '{print "";system("lscfg -vl " $1)}'
  else
    echo "Using: lsdev -Ccdisk | awk '{print \"\";system(\"lscfg -vl \" $1)}' "
    echo "-----------------------"
    echo ""
    lsdev -Ccdisk | awk '{print "";system("lscfg -vl " $1)}'
  fi
}

devrsrv_disk()
{
  # check if EMC powerpath is installed
  #lslpp -L EMCpower.base > /dev/null 2>&1
  #RC_EMCpower=$?
  #if [ $RC_EMCpower -eq 0 ]
  #then
  #  echo "Using: lsdev -Ccdisk | grep hdiskpower | awk '{print \"\";system(\"devrsrv -c query -l \" $1)}' "
  #  echo "-----------------------"
  #  echo ""
  #  lsdev -Ccdisk | grep hdiskpower | awk '{print "";system("devrsrv -c query -l " $1)}'
  #else
    echo "Using: lsdev -Ccdisk | awk '{print \"\";system(\"devrsrv -c query -l \" $1)}' "
    echo "-----------------------"
    echo ""
    lsdev -Ccdisk | awk '{print "";system("devrsrv -c query -l " $1)}'
  #fi
}

vio_vnicstat()
{
  lsdev | grep vnicserver | grep -q Available
  RC_VIO_VNIC=$?
  if [ $RC_VIO_VNIC -eq 0 ]
  then
    for i in $(lsdev | grep vnicserver | grep Available | awk '{print $1}')
    do
      out "==== used command nicstat $1 $i ===="
      vnicstat $1 $i 
    done
  else
    out "No Actve VNIC found"
    out ""
    out "Output of lsdev | grep vnicserver"
    out "---------------------------------"
    lsdev | grep vnicserver
  fi
}

getfiles()
{
  # $1 contain the target directory and $2 the starting string
  Asterix=\*
  Directory=$(dirname ${2})
  Search="$(basename ${2})${Asterix}"
  ActualDir=$(pwd)
  CPDIR=${MainOutDir}/$HOSTNAME/${1}
  if [ -d ${CPDIR} ]
  then
    true
  else
    mkdir -p ${CPDIR}
  fi
  out "Going to copy the files ${Search} to ${MainOutDir}/${HOSTNAME}/${1}"
  out "copied files will get the extention \".txt\" "
  cd ${Directory}
  for i in $Search
  do
    cp $i ${CPDIR}/${i}.txt
  done
  cd ${ActualDir}
}

getSDDdata()
{
  ActualDir=$(pwd)
  CollectDir=${MainOutDir}/$HOSTNAME/${1}
  if [ -d ${CollectDir} ]
  then
    true
  else
    mkdir -p ${CPDIR}
  fi
  cd ${CollectDir}
  out "Using command sddgetdata"
  sddgetdata
  out ""
  out "Using command sddpcmgetdata"
  sddpcmgetdata
  cd ${ActualDir}
}
